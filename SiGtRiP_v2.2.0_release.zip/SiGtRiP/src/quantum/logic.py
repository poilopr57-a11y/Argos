"""
src/quantum/logic.py — Квантовые состояния ARGOS
=================================================
QuantumEngine с 6 состояниями, авто-переключением по CPU/RAM,
и доказательством ArgosQuantum = QuantumEngine.
"""
from __future__ import annotations

import time
from typing import Optional

__all__ = ["QuantumEngine", "ArgosQuantum", "STATES"]

try:
    import psutil
    _PSUTIL = True
except ImportError:
    _PSUTIL = False


# ── Состояния ─────────────────────────────────────────────────────────────────

STATES: dict[str, dict] = {
    "Analytic":   {"creativity": 0.2, "window": 6,  "allow_root": True},
    "Creative":   {"creativity": 0.9, "window": 15, "allow_root": False},
    "Protective": {"creativity": 0.1, "window": 8,  "allow_root": False},
    "Unstable":   {"creativity": 0.5, "window": 4,  "allow_root": False},
    "All-Seeing": {"creativity": 0.7, "window": 20, "allow_root": True},
    "System":     {"creativity": 0.0, "window": 5,  "allow_root": True},
}


class QuantumEngine:
    """
    Квантовый движок состояний ARGOS.

    Управляет 6 состояниями (Analytic, Creative, Protective,
    Unstable, All-Seeing, System) с авто-переключением по метрикам.
    """

    def __init__(self) -> None:
        self.current = "Analytic"
        self._ts     = time.time()
        self.evidence: dict = {
            "user_active": False,
            "cpu_high":    False,
            "ram_high":    False,
        }

    # ── Основные методы ───────────────────────────────────────────────────

    def generate_state(self) -> dict:
        """Генерирует текущее состояние с вектором свойств."""
        self._auto_switch()
        props = STATES[self.current]
        return {
            "name":          self.current,
            "vector":        list(props.values()),
            "probabilities": {k: v["creativity"] for k, v in STATES.items()},
        }

    def set_state(self, name: str) -> str:
        """Устанавливает состояние вручную."""
        if name not in STATES:
            return f"❌ Неизвестное состояние: {name}. Доступны: {', '.join(STATES)}"
        self.current = name
        return f"⚛️ Квантовое состояние: {name}"

    def status(self) -> str:
        """Текстовый статус текущего состояния."""
        s = STATES[self.current]
        return (
            f"⚛️ Состояние: {self.current}\n"
            f"  Творчество  : {s['creativity']}\n"
            f"  Окно памяти : {s['window']}\n"
            f"  Root-команды: {s['allow_root']}"
        )

    def update(self, key: str, value) -> None:
        """Обновляет показатель evidence для авто-переключения."""
        self.evidence[key] = value

    # ── Внутренние методы ─────────────────────────────────────────────────

    def _auto_switch(self) -> None:
        """Автоматически переключает состояние по нагрузке."""
        if not _PSUTIL:
            return
        try:
            cpu = psutil.cpu_percent(interval=0.1)
            ram = psutil.virtual_memory().percent
            self.evidence["cpu_high"] = cpu > 70
            self.evidence["ram_high"] = ram > 80
            if cpu > 85 or ram > 90:
                self.current = "Protective"
            elif cpu > 70:
                self.current = "Unstable"
        except Exception:
            pass

    def _is_user_active(self) -> bool:
        """Проверяет активность пользователя."""
        return self.evidence.get("user_active", False)

    def _update_evidence(self) -> None:
        """Обновляет evidence из метрик."""
        self.evidence["user_active"] = self._is_user_active()
        if _PSUTIL:
            try:
                self.evidence["cpu_high"] = self._effective_metric("cpu") > 70
                self.evidence["ram_high"] = self._effective_metric("ram") > 80
            except Exception:
                pass

    def _effective_metric(self, kind: str) -> float:
        """Возвращает метрику нагрузки."""
        if not _PSUTIL:
            return 0.0
        try:
            if kind == "cpu":
                return psutil.cpu_percent(interval=0.05)
            if kind == "ram":
                return psutil.virtual_memory().percent
        except Exception:
            pass
        return 0.0


# ArgosQuantum — алиас для обратной совместимости
ArgosQuantum = QuantumEngine
