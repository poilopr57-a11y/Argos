"""src/memory.py — Долгосрочная память ARGOS"""
from __future__ import annotations
import os, sqlite3, threading
from pathlib import Path
from typing import Optional

__all__ = ["ArgosMemory"]
DB_PATH = os.environ.get("ARGOS_VECTOR_FORCE_FALLBACK", "") and "data/memory_test.db" or "data/memory.db"


class ArgosMemory:
    def __init__(self, db_path: str = DB_PATH) -> None:
        self._db_path = db_path
        Path(db_path).parent.mkdir(parents=True, exist_ok=True)
        self._conn = sqlite3.connect(db_path, check_same_thread=False)
        self._lock = threading.RLock()
        self._grist = None
        self._init_db()

    def _init_db(self) -> None:
        with self._lock:
            self._conn.execute("""CREATE TABLE IF NOT EXISTS memory (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                category TEXT DEFAULT 'general',
                key TEXT NOT NULL, value TEXT NOT NULL,
                ts REAL DEFAULT (strftime('%s','now')))""")
            self._conn.commit()

    def attach_grist(self, grist) -> None:
        self._grist = grist

    def remember(self, key: str, value: str, category: str = "general") -> str:
        with self._lock:
            self._conn.execute(
                "INSERT OR REPLACE INTO memory (category,key,value) VALUES(?,?,?)",
                (category, key, value))
            self._conn.commit()
        if self._grist and getattr(self._grist, "_configured", False):
            try:
                self._grist.save(f"memory:{category}:{key}", value)
            except Exception:
                pass
        return f"✅ Запомнил: {key} = {value}"

    def recall(self, key: str, category: str = "") -> Optional[str]:
        q = "SELECT value FROM memory WHERE key=?" + (" AND category=?" if category else "")
        params = (key, category) if category else (key,)
        with self._lock:
            row = self._conn.execute(q, params).fetchone()
        return row[0] if row else None

    def search(self, query: str) -> str:
        with self._lock:
            rows = self._conn.execute(
                "SELECT category,key,value FROM memory WHERE key LIKE ? OR value LIKE ? LIMIT 10",
                (f"%{query}%", f"%{query}%")).fetchall()
        if not rows: return f"🔍 По запросу «{query}» ничего не найдено"
        lines = [f"🔍 Найдено: {len(rows)}"]
        for cat, k, v in rows:
            lines.append(f"  [{cat}] {k}: {v[:60]}")
        return "\n".join(lines)

    def all_facts(self, limit: int = 20) -> str:
        with self._lock:
            rows = self._conn.execute(
                "SELECT category,key,value FROM memory ORDER BY id DESC LIMIT ?",
                (limit,)).fetchall()
        if not rows: return "📭 Память пуста"
        lines = ["🧠 ПАМЯТЬ:"]
        for cat, k, v in rows:
            lines.append(f"  [{cat}] {k}: {v[:60]}")
        return "\n".join(lines)

    def status(self) -> str:
        with self._lock:
            count = self._conn.execute("SELECT COUNT(*) FROM memory").fetchone()[0]
        grist = "✅" if self._grist else "❌"
        return f"🧠 Память: {count} фактов | Grist: {grist}"
