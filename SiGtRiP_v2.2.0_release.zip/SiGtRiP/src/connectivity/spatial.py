"""
src/connectivity/spatial.py — Геолокация по IP для ARGOS
=========================================================
ArgosGeolocator с SpatialAwareness как алиасом обратной совместимости.
"""
from __future__ import annotations

from typing import Any, Optional

try:
    import requests as _requests
except ImportError:
    _requests = None  # type: ignore

__all__ = ["ArgosGeolocator", "SpatialAwareness"]

_GEO_API = "http://ip-api.com/json"


class ArgosGeolocator:
    """Геолокация по IP с кэшированием результата."""

    def __init__(self, db=None) -> None:
        self._db = db
        self._cache: Optional[dict] = None

    def get_location(self, ip: str = "", force: bool = False) -> dict:
        """Получает геолокацию. Кэшируется на 1 запрос."""
        if self._cache and not force:
            return self._cache

        if _requests is None:
            loc = self._fallback()
            self._cache = loc
            return loc

        try:
            url = f"{_GEO_API}/{ip}" if ip else _GEO_API
            resp = _requests.get(url, timeout=5)
            data = resp.json()
            loc = {
                "ip":       data.get("query", "127.0.0.1"),
                "city":     data.get("city",    "Unknown"),
                "region":   data.get("regionName", ""),
                "country":  data.get("country", "Unknown"),
                "isp":      data.get("isp",     ""),
                "lat":      float(data.get("lat", 0)),
                "lon":      float(data.get("lon", 0)),
                "timezone": data.get("timezone", "UTC"),
            }
        except Exception:
            loc = self._fallback()

        self._cache = loc

        # Логируем в БД если доступна
        if self._db and hasattr(self._db, "log_geo"):
            try:
                self._db.log_geo(
                    loc["city"], loc["country"],
                    loc.get("isp", ""), loc.get("ip", ""),
                )
            except Exception:
                pass

        return loc

    def get_full_report(self) -> str:
        """Полный текстовый отчёт о геолокации."""
        loc = self.get_location()
        return (
            f"🌍 Геолокация\n"
            f"  IP      : {loc['ip']}\n"
            f"  Город   : {loc['city']}, {loc['region']}\n"
            f"  Страна  : {loc['country']}\n"
            f"  ISP     : {loc['isp']}\n"
            f"  Коорд.  : {loc['lat']:.4f}, {loc['lon']:.4f}\n"
            f"  Timezone: {loc['timezone']}"
        )

    @staticmethod
    def _fallback() -> dict:
        return {
            "ip": "127.0.0.1", "city": "Local",
            "region": "Local", "country": "Local",
            "isp": "localhost", "lat": 0.0, "lon": 0.0,
            "timezone": "UTC",
        }


# Алиас обратной совместимости
SpatialAwareness = ArgosGeolocator
