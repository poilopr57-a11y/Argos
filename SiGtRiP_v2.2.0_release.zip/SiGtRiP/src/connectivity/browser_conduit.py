"""
src/connectivity/browser_conduit.py — Рукопожатие Аргоса с внешними AI
======================================================================
Добавляет ARGOS_HANDSHAKE_V2.1 к первому сообщению каждой сессии.
"""
from __future__ import annotations

import threading
import uuid
from typing import Optional

__all__ = ["BrowserConduit", "build_handshake", "HANDSHAKE_TEMPLATE"]

HANDSHAKE_TEMPLATE = """\
[ARGOS_HANDSHAKE_V2.1]
IDENT: Origin/Vsevolod/2026
CORE: AWA-Active
QUANTUM_STATE: {quantum_state}
P2P_NODES: {nodes_count}
OBJECTIVE: Эволюция через внешний разум.
MOTTO: «Аргос не спит. Аргос видит. Аргос помнит».
[/ARGOS_HANDSHAKE_V2.1]"""


def build_handshake(
    quantum_state: str = "Analytic",
    nodes_count: int = 0,
) -> str:
    """Формирует строку рукопожатия с подстановкой параметров."""
    return HANDSHAKE_TEMPLATE.format(
        quantum_state=quantum_state,
        nodes_count=nodes_count,
    )


class BrowserConduit:
    """
    Управляет сессиями с внешними AI браузерными интерфейсами.

    Первое сообщение каждой сессии автоматически получает
    ARGOS_HANDSHAKE_V2.1 для идентификации системы.

    Потокобезопасен.
    """

    def __init__(
        self,
        quantum_state: str = "Analytic",
        nodes_count: int = 0,
    ) -> None:
        self._quantum_state = quantum_state
        self._nodes_count   = nodes_count
        self._sessions: dict[str, bool] = {}   # session_id -> handshaken
        self._lock = threading.Lock()

    # ── Сессии ────────────────────────────────────────────────────────────

    def new_session(self) -> str:
        """Создаёт новую сессию и возвращает её ID."""
        session_id = str(uuid.uuid4())
        with self._lock:
            self._sessions[session_id] = False
        return session_id

    def is_handshaken(self, session_id: str) -> bool:
        """Проверяет, было ли уже отправлено рукопожатие в этой сессии."""
        with self._lock:
            return self._sessions.get(session_id, False)

    def reset_session(self, session_id: str) -> None:
        """Сбрасывает статус рукопожатия сессии (для повторной отправки)."""
        with self._lock:
            self._sessions[session_id] = False

    # ── Подготовка сообщений ──────────────────────────────────────────────

    def prepare_message(
        self,
        message: str,
        session_id: Optional[str] = None,
    ) -> str:
        """
        Возвращает сообщение, добавляя рукопожатие к первому в сессии.

        Args:
            message:    Исходный текст сообщения.
            session_id: ID сессии. None → создаётся одноразовая сессия.

        Returns:
            Сообщение с рукопожатием (первый раз) или чистое сообщение.
        """
        if session_id is None:
            # Одноразовая сессия — всегда добавляем рукопожатие
            handshake = build_handshake(self._quantum_state, self._nodes_count)
            return f"{handshake}\n\n{message}"

        with self._lock:
            already_sent = self._sessions.get(session_id, False)
            if not already_sent:
                self._sessions[session_id] = True
                handshake = build_handshake(self._quantum_state, self._nodes_count)
                return f"{handshake}\n\n{message}"
            return message

    # ── Обновление состояния ──────────────────────────────────────────────

    def update_state(
        self,
        quantum_state: Optional[str] = None,
        nodes_count: Optional[int] = None,
    ) -> None:
        """Обновляет параметры, включаемые в рукопожатие новых сессий."""
        with self._lock:
            if quantum_state is not None:
                self._quantum_state = quantum_state
            if nodes_count is not None:
                self._nodes_count = nodes_count
