"""
src/connectivity/colibri_daemon.py — Демон Колибри
===================================================
Фоновый системный сервис ARGOS с поддержкой daemon-режима.
"""
from __future__ import annotations

import argparse
import os
import sys
import time
from pathlib import Path
from typing import Optional

__all__ = ["ColibriDaemon", "run_daemon_background", "_parse_args"]


def _parse_args(args: list[str] | None = None) -> argparse.Namespace:
    """Парсит аргументы командной строки."""
    parser = argparse.ArgumentParser(description="ARGOS Colibri Daemon")
    parser.add_argument("--daemon",    action="store_true", help="Запустить как фоновый демон")
    parser.add_argument("--pid-file",  default="data/colibri.pid", help="Путь к PID-файлу")
    parser.add_argument("--work-dir",  default="data/colibri", help="Рабочая директория")
    parser.add_argument("--node-id",   default="colibri_main", help="ID ноды")
    parser.add_argument("--port",      type=int, default=5000, help="Порт")
    parser.add_argument("--no-budding",action="store_true", help="Отключить почкование")
    return parser.parse_args(args)


def run_daemon_background(args: argparse.Namespace) -> None:
    """
    Запускает процесс в режиме unix-демона (двойной fork).
    Требует пакет python-daemon.
    """
    try:
        import daemon  # type: ignore[import]
    except ImportError:
        print("❌ python-daemon не установлен: pip install python-daemon")
        sys.exit(1)

    pid_path = Path(args.pid_file)
    pid_path.parent.mkdir(parents=True, exist_ok=True)

    with daemon.DaemonContext(pidfile=pid_path):
        _run_colibri(args)


def _run_colibri(args: argparse.Namespace) -> None:
    """Основной цикл демона Колибри."""
    work_dir = Path(args.work_dir)
    work_dir.mkdir(parents=True, exist_ok=True)

    while True:
        # Основная работа демона
        time.sleep(10)


class ColibriDaemon:
    """Демон Колибри — фоновый сервис ARGOS."""

    def __init__(self, node_id: str = "colibri", port: int = 5000) -> None:
        self.node_id = node_id
        self.port    = port
        self._running = False

    def start(self) -> str:
        self._running = True
        return f"🐦 Колибри запущен: {self.node_id}:{self.port}"

    def stop(self) -> str:
        self._running = False
        return "🐦 Колибри остановлен"

    def status(self) -> str:
        state = "работает" if self._running else "остановлен"
        return f"🐦 Колибри [{self.node_id}]: {state}"


if __name__ == "__main__":
    parsed = _parse_args()
    if parsed.daemon:
        run_daemon_background(parsed)
    else:
        daemon = ColibriDaemon(node_id=parsed.node_id, port=parsed.port)
        print(daemon.start())
        try:
            while True:
                time.sleep(1)
        except KeyboardInterrupt:
            print(daemon.stop())
