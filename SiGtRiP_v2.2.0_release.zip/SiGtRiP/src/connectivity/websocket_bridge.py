"""src/connectivity/websocket_bridge.py"""
from __future__ import annotations
__all__ = ["WebSocketBridge"]
class WebSocketBridge:
    def __init__(self, server_host: str = "0.0.0.0", server_port: int = 8765) -> None:
        self.server_host = server_host; self.server_port = server_port
    def available(self) -> bool:
        try: import websockets; return True
        except ImportError: return False
    def status(self) -> str:
        return f"🔌 WebSocket: {'✅' if self.available() else '❌'} {self.server_host}:{self.server_port}"
