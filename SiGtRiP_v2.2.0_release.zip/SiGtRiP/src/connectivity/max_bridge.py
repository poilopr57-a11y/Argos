"""src/connectivity/max_bridge.py — Mail.ru MAX Bot API"""
import os
__all__ = ["MaxBridge"]
try:
    import requests as _req
except ImportError:
    _req = None  # type: ignore

_BASE = os.environ.get("MAX_BOT_API_BASE","https://botapi.max.ru")

class MaxBridge:
    def __init__(self, bot_token: str = "") -> None:
        self._token = bot_token or os.environ.get("MAX_BOT_TOKEN","")

    def send_message(self, chat_id: str, text: str = "") -> dict:
        if _req is None: return {"ok": False, "provider": "max", "error": "requests missing"}
        try:
            r = _req.post(f"{_BASE}/messages",
                          headers={"Authorization": f"Bearer {self._token}"},
                          json={"chat_id": chat_id, "text": text}, timeout=10)
            r.raise_for_status()
            return {"ok": True, "provider": "max", "data": r.json()}
        except Exception as e:
            return {"ok": False, "provider": "max", "error": str(e)}
