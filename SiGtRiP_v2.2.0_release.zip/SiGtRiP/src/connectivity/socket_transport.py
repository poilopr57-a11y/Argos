"""src/connectivity/socket_transport.py"""
from __future__ import annotations
import socket, threading
__all__ = ["SocketTransport"]

class SocketTransport:
    def __init__(self, host: str = "0.0.0.0", port: int = 0, protocol: str = "tcp") -> None:
        self.host = host; self.port = port; self.protocol = protocol
        self._server_sock = None; self._running = False

    def send_message(self, host: str, port: int, message: str, timeout: int = 5) -> dict:
        if self.protocol == "udp":
            try:
                s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
                s.sendto(message.encode(), (host, port)); s.close()
                return {"ok": True, "provider": "socket_udp"}
            except Exception as e:
                return {"ok": False, "provider": "socket_udp", "error": str(e)}
        try:
            s = socket.create_connection((host, port), timeout=timeout)
            s.sendall(message.encode())
            data = s.recv(4096).decode()
            s.close()
            return {"ok": True, "data": data, "provider": "socket_tcp"}
        except Exception as e:
            return {"ok": False, "error": str(e)}

    def start_server(self, handler=None) -> dict:
        try:
            if self.protocol == "udp":
                self._server_sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
            else:
                self._server_sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
                self._server_sock.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
            self._server_sock.bind((self.host, self.port))
            if self.protocol == "tcp": self._server_sock.listen(5)
            actual_port = self._server_sock.getsockname()[1]
            self.port = actual_port; self._running = True
            return {"ok": True, "port": actual_port}
        except Exception as e:
            return {"ok": False, "error": str(e)}

    def stop_server(self) -> None:
        self._running = False
        if self._server_sock:
            try: self._server_sock.close()
            except Exception: pass
