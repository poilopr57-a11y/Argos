"""src/connectivity/aiogram_bridge.py"""
from __future__ import annotations
__all__ = ["AiogramBridge"]
class AiogramBridge:
    def __init__(self, token: str = "") -> None:
        self._token = token
        self._bot = None; self._dp = None
        if token:
            try:
                from aiogram import Bot, Dispatcher
                self._bot = Bot(token=token)
                self._dp  = Dispatcher()
            except Exception: pass
    def _ready(self) -> bool: return bool(self._token and self._bot)
    @property
    def bot(self): return self._bot
    @property
    def dispatcher(self): return self._dp
    def status(self) -> str:
        return f"🤖 aiogram: {'✅' if self._ready() else '❌'}"
