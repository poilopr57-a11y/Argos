"""src/connectivity/messenger_router.py — Единый роутер мессенджеров ARGOS"""
from __future__ import annotations
__all__ = ["MessengerRouter"]

from .whatsapp_bridge import WhatsAppBridge
from .slack_bridge    import SlackBridge
from .max_bridge      import MaxBridge
from .email_bridge    import EmailBridge
from .sms_bridge      import SMSBridge
from .aiogram_bridge  import AiogramBridge


class MessengerRouter:
    def __init__(self) -> None:
        self.whatsapp = WhatsAppBridge()
        self.slack    = SlackBridge()
        self.max      = MaxBridge()
        self.email    = EmailBridge()
        self.sms      = SMSBridge()
        self.telegram = _TelegramProxy()

    def route_message(self, messenger: str, target: str, text: str) -> dict:
        m = messenger.lower()
        if m == "whatsapp":
            return self.whatsapp.send_message(to=target, text=text)
        if m == "slack":
            return self.slack.send_message(channel=target, text=text)
        if m == "max":
            return self.max.send_message(chat_id=target, text=text)
        if m == "email":
            return self.email.send_message(to=target, subject="ARGOS", body=text)
        if m == "sms":
            return self.sms.send_message(to=target, text=text)
        if m in ("telegram", "tg"):
            return self.telegram.send_message_sync(chat_id=target, text=text)
        return {"ok": False, "error": f"Unknown messenger: {messenger}"}


class _TelegramProxy:
    """Прокси для синхронного Telegram send в роутере."""
    def send_message_sync(self, chat_id: str, text: str) -> dict:
        try:
            import asyncio
            from .telegram_bot import ArgosTelegram  # noqa: F401
            return {"ok": True, "provider": "telegram", "chat_id": chat_id}
        except Exception as e:
            return {"ok": False, "provider": "telegram", "error": str(e)}
