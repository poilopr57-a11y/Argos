"""src/connectivity/slack_bridge.py"""
import os
__all__ = ["SlackBridge"]
try:
    import requests as _req
except ImportError:
    _req = None  # type: ignore

class SlackBridge:
    def __init__(self, bot_token: str = "", app_token: str = "") -> None:
        self._token     = bot_token or os.environ.get("SLACK_BOT_TOKEN","")
        self._app_token = app_token or os.environ.get("SLACK_APP_TOKEN","")

    def socket_mode_ready(self) -> bool:
        return bool(self._app_token)

    def send_message(self, channel: str, text: str = "") -> dict:
        if _req is None: return {"ok": False, "provider": "slack", "error": "requests missing"}
        try:
            r = _req.post("https://slack.com/api/chat.postMessage",
                          headers={"Authorization": f"Bearer {self._token}"},
                          json={"channel": channel, "text": text}, timeout=10)
            r.raise_for_status()
            d = r.json()
            return {"ok": d.get("ok", False), "provider": "slack", "data": d}
        except Exception as e:
            return {"ok": False, "provider": "slack", "error": str(e)}
