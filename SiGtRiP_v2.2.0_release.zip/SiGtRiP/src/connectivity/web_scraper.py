"""src/connectivity/web_scraper.py"""
from __future__ import annotations
__all__ = ["WebScraper"]
try:
    import requests as _req
except ImportError:
    _req = None  # type: ignore

class WebScraper:
    def available(self) -> bool:
        try: from bs4 import BeautifulSoup; return True
        except ImportError: return False
    def fetch(self, url: str, timeout: int = 10) -> dict:
        if _req is None: return {"ok": False, "error": "requests not installed"}
        try:
            r = _req.get(url, timeout=timeout)
            r.raise_for_status()
            if self.available():
                from bs4 import BeautifulSoup
                data = BeautifulSoup(r.text, "html.parser").get_text()[:5000]
            else:
                data = r.text[:5000]
            return {"ok": True, "data": data, "status_code": r.status_code}
        except Exception as e:
            return {"ok": False, "error": str(e)}
    def scrape(self, url: str, selector: str = "a", attr: str = "href") -> dict:
        if not self.available(): return {"ok": False, "error": "beautifulsoup4 not installed"}
        r = self.fetch(url)
        if not r["ok"]: return r
        from bs4 import BeautifulSoup
        soup = BeautifulSoup(r.get("data",""), "html.parser")
        items = [t.get(attr,"") for t in soup.select(selector) if t.get(attr)]
        return {"ok": True, "data": items}
    def parse_html(self, html: str):
        from bs4 import BeautifulSoup
        return BeautifulSoup(html, "html.parser")
