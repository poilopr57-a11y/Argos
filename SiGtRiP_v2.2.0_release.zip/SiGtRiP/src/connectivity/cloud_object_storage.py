"""src/connectivity/cloud_object_storage.py — IBM COS + S3"""
from __future__ import annotations
import os
from typing import Optional

__all__ = ["IBMCloudObjectStorage"]


class IBMCloudObjectStorage:
    def __init__(self, endpoint: str = "", api_key: str = "",
                 resource_instance_id: str = "", access_key_id: str = "",
                 secret_access_key: str = "", bucket: str = "") -> None:
        self._endpoint  = endpoint
        self._api_key   = api_key
        self._rid       = resource_instance_id
        self._ak        = access_key_id
        self._sk        = secret_access_key
        self._bucket    = bucket

    @classmethod
    def from_env(cls) -> "IBMCloudObjectStorage":
        return cls(
            endpoint            = os.environ.get("IBM_COS_ENDPOINT", ""),
            api_key             = os.environ.get("IBM_COS_API_KEY", ""),
            resource_instance_id= os.environ.get("IBM_COS_RESOURCE_INSTANCE_ID", ""),
            access_key_id       = os.environ.get("IBM_COS_ACCESS_KEY_ID", ""),
            secret_access_key   = os.environ.get("IBM_COS_SECRET_ACCESS_KEY", ""),
            bucket              = os.environ.get("IBM_COS_BUCKET", ""),
        )

    def is_configured(self) -> bool:
        return bool(self._endpoint and (self._api_key or self._ak))

    def status(self) -> str:
        if not self.is_configured():
            return "☁️ IBM COS не настроен"
        return f"☁️ IBM COS: {self._endpoint[:30]}... | bucket={self._bucket}"

    def upload(self, key: str, data: bytes) -> bool:
        if not self.is_configured():
            return False
        try:
            import boto3
            s3 = boto3.client(
                "s3",
                endpoint_url        = self._endpoint,
                aws_access_key_id   = self._ak,
                aws_secret_access_key = self._sk,
            )
            s3.put_object(Bucket=self._bucket, Key=key, Body=data)
            return True
        except Exception:
            return False

    def download(self, key: str) -> Optional[bytes]:
        if not self.is_configured():
            return None
        try:
            import boto3
            s3 = boto3.client(
                "s3",
                endpoint_url          = self._endpoint,
                aws_access_key_id     = self._ak,
                aws_secret_access_key = self._sk,
            )
            obj = s3.get_object(Bucket=self._bucket, Key=key)
            return obj["Body"].read()
        except Exception:
            return None
