"""src/connectivity/sensor_bridge.py — Системные сенсоры ARGOS"""
from __future__ import annotations
import socket, time
from typing import Optional

__all__ = ["ArgosSensorBridge"]


class ArgosSensorBridge:
    """Мост к системным датчикам: CPU, RAM, диск, температура, сеть."""

    def get_full_report(self) -> str:
        lines = ["📊 СИСТЕМА:"]
        try:
            import psutil
            cpu   = psutil.cpu_percent(interval=0.1)
            ram   = psutil.virtual_memory()
            disk  = psutil.disk_usage("/")
            lines += [
                f"  CPU  : {cpu:.1f}%",
                f"  RAM  : {ram.percent:.1f}% ({ram.used//1024//1024}/{ram.total//1024//1024} MB)",
                f"  Disk : {disk.percent:.1f}%",
            ]
            temps = getattr(psutil, "sensors_temperatures", None)
            if temps:
                t = temps()
                if t:
                    temp_list = list(t.values())[0]
                    if temp_list:
                        lines.append(f"  Temp : {temp_list[0].current:.0f}°C")
        except Exception:
            lines.append("  psutil недоступен")
        ping = self._ping_status()
        lines.append(f"  Net  : {ping['status']} ({ping['ping']})")
        return "\n".join(lines)

    def _ping_status(self) -> dict:
        try:
            t0 = time.time()
            with socket.create_connection(("8.8.8.8", 53), timeout=2):
                ms = (time.time() - t0) * 1000
            return {"ping": f"{ms:.0f}ms", "status": "Stable"}
        except OSError:
            return {"ping": "inf", "status": "Offline"}

    def cpu(self) -> float:
        try:
            import psutil
            return psutil.cpu_percent(interval=0.1)
        except Exception:
            return 0.0

    def ram(self) -> dict:
        try:
            import psutil
            m = psutil.virtual_memory()
            return {"percent": m.percent, "total_mb": m.total // 1024 // 1024,
                    "used_mb": m.used // 1024 // 1024}
        except Exception:
            return {"percent": 0.0, "total_mb": 0, "used_mb": 0}
