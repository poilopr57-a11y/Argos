"""src/connectivity/telegram_bot.py — Telegram бот ARGOS"""
from __future__ import annotations
import os
from typing import Optional

__all__ = ["ArgosTelegram", "HISTORY_MESSAGES_LIMIT"]

HISTORY_MESSAGES_LIMIT = 20

_PLACEHOLDER_TOKENS = {"", "your_token_here", "your_token", "none",
                       "null", "changeme", "токен", "token"}


class ArgosTelegram:
    def __init__(self, core=None, admin=None, flasher=None) -> None:
        self._core    = core
        self._admin   = admin
        self._flasher = flasher
        self.token    = os.environ.get("TELEGRAM_BOT_TOKEN","")
        self.user_id  = os.environ.get("USER_ID","")
        self.allowed_ids = {uid.strip() for uid in self.user_id.split(",") if uid.strip()}
        self.app      = None
        self.voice_on = False

    # ── Auth ──────────────────────────────────────────────────────────────
    def _auth(self, update) -> bool:
        uid = str(getattr(getattr(update, "effective_user", None), "id", ""))
        if not self.allowed_ids: return False
        return uid in self.allowed_ids

    def can_start(self) -> tuple[bool, str]:
        t = self.token.strip().lower()
        if not t or t in _PLACEHOLDER_TOKENS:
            return False, "❌ Токен не задан или является placeholder"
        if ":" not in self.token:
            return False, "❌ Неверный формат токена (нужен ':')"
        parts = self.token.split(":", 1)
        if len(parts[1]) < 20:
            return False, "❌ Секрет токена слишком короткий"
        if not self.user_id.strip():
            return False, "❌ USER_ID не задан"
        return True, "ok"

    # ── Commands ──────────────────────────────────────────────────────────
    async def cmd_start(self, update, context) -> None:
        from telegram import KeyboardButton, ReplyKeyboardMarkup
        buttons = [[KeyboardButton("/status"), KeyboardButton("/history"),
                    KeyboardButton("/skills"), KeyboardButton("/crypto")],
                   [KeyboardButton("/alerts"),  KeyboardButton("/apk"),
                    KeyboardButton("/voice_on"), KeyboardButton("/voice_off")],
                   [KeyboardButton("/help")]]
        markup = ReplyKeyboardMarkup(buttons, resize_keyboard=True)
        await update.message.reply_text("🔱 ARGOS готов.", reply_markup=markup)

    async def cmd_history(self, update, context) -> None:
        db = getattr(self._core, "db", None)
        if db and hasattr(db, "format_history"):
            text = db.format_history(HISTORY_MESSAGES_LIMIT)
        else:
            text = "📭 История недоступна."
        await update.message.reply_text(text)

    async def cmd_status(self, update, context) -> None:
        if not self._auth(update): return
        text = "📊 ARGOS: активен" if self._core else "❌ Ядро не загружено"
        await update.message.reply_text(text)

    # ── APK build ─────────────────────────────────────────────────────────
    def _build_apk_sync(self) -> tuple[bool, str]:
        import shlex, subprocess
        cmd_str = os.environ.get("ARGOS_APK_BUILD_CMD", "").strip()
        if not cmd_str:
            return False, "❌ ARGOS_APK_BUILD_CMD не задан"
        try:
            subprocess.run(shlex.split(cmd_str), check=True)
        except subprocess.CalledProcessError as e:
            return False, f"❌ Сборка завершилась с ошибкой: {e}"
        except Exception as e:
            return False, f"❌ {e}"
        apk = self._find_apk_artifact()
        if not apk:
            return False, "❌ APK не найден после сборки"
        return True, apk

    def _find_apk_artifact(self) -> Optional[str]:
        import glob
        files = glob.glob("bin/*.apk") + glob.glob("*.apk")
        return files[0] if files else None

    def run(self) -> None:
        ok, reason = self.can_start()
        if not ok:
            print(f"[TG] Не запущен: {reason}")
            return
        try:
            from telegram.ext import Application, CommandHandler, MessageHandler, filters
            app = Application.builder().token(self.token).build()
            app.add_handler(CommandHandler("start",   self.cmd_start))
            app.add_handler(CommandHandler("history", self.cmd_history))
            app.add_handler(CommandHandler("status",  self.cmd_status))
            self.app = app
            app.run_polling()
        except Exception as e:
            print(f"[TG] Ошибка: {e}")
