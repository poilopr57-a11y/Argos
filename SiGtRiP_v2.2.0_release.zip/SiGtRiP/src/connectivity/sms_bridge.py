"""src/connectivity/sms_bridge.py"""
from __future__ import annotations
import os
__all__ = ["SMSBridge"]

try:
    from smsmobileapi import SMSMobileAPI as _SMSMobileAPI
except ImportError:
    _SMSMobileAPI = None  # type: ignore

class SMSBridge:
    def __init__(self, api_key: str = "") -> None:
        self._key = api_key or os.environ.get("SMSMOBILEAPI_KEY","")
        self._client = _SMSMobileAPI(self._key) if _SMSMobileAPI and self._key else None
    def is_configured(self) -> bool: return bool(self._key)
    def send_message(self, to: str, text: str = "") -> dict:
        if not self._client: return {"ok": False, "provider": "sms", "error": "not configured"}
        try:
            r = self._client.send_sms(to, text)
            return {"ok": True, "provider": "sms", "data": r}
        except Exception as e:
            return {"ok": False, "provider": "sms", "error": str(e)}
    def receive_messages(self) -> dict:
        if not self._client: return {"ok": False, "provider": "sms", "error": "not configured"}
        try:
            r = self._client.get_sms()
            return {"ok": True, "provider": "sms", "data": r}
        except Exception as e:
            return {"ok": False, "provider": "sms", "error": str(e)}
