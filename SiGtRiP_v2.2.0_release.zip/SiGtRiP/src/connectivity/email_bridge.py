"""src/connectivity/email_bridge.py"""
from __future__ import annotations
import imaplib, smtplib
from email.mime.text import MIMEText
from email.mime.multipart import MIMEMultipart

__all__ = ["EmailBridge"]


class EmailBridge:
    def __init__(self, username: str = "", password: str = "",
                 smtp_host: str = "smtp.gmail.com", smtp_port: int = 587,
                 imap_host: str = "imap.gmail.com", use_ssl: bool = True) -> None:
        self._user = username
        self._pass = password
        self._smtp_host = smtp_host
        self._smtp_port = smtp_port
        self._imap_host = imap_host
        self._use_ssl   = use_ssl

    def is_configured(self) -> bool:
        return bool(self._user and self._pass)

    def send_message(self, to: str, subject: str = "ARGOS", body: str = "") -> dict:
        if not self.is_configured():
            return {"ok": False, "provider": "email", "error": "not configured"}
        try:
            msg = MIMEMultipart()
            msg["From"] = self._user; msg["To"] = to; msg["Subject"] = subject
            msg.attach(MIMEText(body, "plain"))
            if self._use_ssl:
                with smtplib.SMTP_SSL(self._smtp_host, 465) as srv:
                    srv.login(self._user, self._pass)
                    srv.sendmail(self._user, to, msg.as_string())
            else:
                with smtplib.SMTP(self._smtp_host, self._smtp_port) as srv:
                    srv.starttls(); srv.login(self._user, self._pass)
                    srv.sendmail(self._user, to, msg.as_string())
            return {"ok": True, "provider": "email"}
        except Exception as e:
            return {"ok": False, "provider": "email", "error": str(e)}

    def fetch_messages(self, limit: int = 10, folder: str = "INBOX") -> dict:
        if not self.is_configured():
            return {"ok": False, "provider": "email", "error": "not configured"}
        try:
            conn = imaplib.IMAP4_SSL(self._imap_host)
            conn.login(self._user, self._pass)
            conn.select(folder)
            _, ids_data = conn.search(None, "ALL")
            ids = ids_data[0].split()[-limit:]
            messages = []
            for mid in ids:
                _, data = conn.fetch(mid, "(RFC822)")
                for part in data:
                    if isinstance(part, tuple):
                        messages.append({"raw": part[1].decode(errors="replace")})
            conn.logout()
            return {"ok": True, "provider": "email", "data": messages}
        except Exception as e:
            return {"ok": False, "provider": "email", "error": str(e)}
