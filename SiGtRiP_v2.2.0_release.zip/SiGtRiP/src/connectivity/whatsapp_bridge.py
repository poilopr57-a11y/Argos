"""src/connectivity/whatsapp_bridge.py"""
import os
__all__ = ["WhatsAppBridge"]
try:
    import requests as _req
except ImportError:
    _req = None  # type: ignore

class WhatsAppBridge:
    def __init__(self, cloud_token: str = "", phone_number_id: str = "",
                 twilio_account_sid: str = "", twilio_auth_token: str = "",
                 twilio_whatsapp_from: str = "") -> None:
        self._cloud_token = cloud_token or os.environ.get("WHATSAPP_ACCESS_TOKEN","")
        self._phone_id    = phone_number_id or os.environ.get("WHATSAPP_PHONE_NUMBER_ID","")
        self._twilio_sid  = twilio_account_sid
        self._twilio_auth = twilio_auth_token
        self._twilio_from = twilio_whatsapp_from

    def send_message(self, to: str, text: str = "") -> dict:
        if _req is None: return {"ok": False, "provider": "whatsapp", "error": "requests missing"}
        # Cloud API
        try:
            url = f"https://graph.facebook.com/v18.0/{self._phone_id}/messages"
            r = _req.post(url, headers={"Authorization": f"Bearer {self._cloud_token}"},
                          json={"messaging_product":"whatsapp","to":to,
                                "type":"text","text":{"body":text}}, timeout=10)
            r.raise_for_status()
            return {"ok": True, "provider": "whatsapp_cloud", "data": r.json()}
        except Exception as e1:
            # Twilio fallback
            if self._twilio_sid:
                try:
                    r2 = _req.post(
                        f"https://api.twilio.com/2010-04-01/Accounts/{self._twilio_sid}/Messages.json",
                        auth=(self._twilio_sid, self._twilio_auth),
                        data={"From": f"whatsapp:{self._twilio_from}",
                              "To": f"whatsapp:{to}", "Body": text}, timeout=10)
                    r2.raise_for_status()
                    return {"ok": True, "provider": "twilio", "data": r2.json()}
                except Exception as e2:
                    return {"ok": False, "provider": "whatsapp", "error": str(e2)}
            return {"ok": False, "provider": "whatsapp", "error": str(e1)}
