"""src/connectivity/whisper_node.py — P2P WhisperNode"""
from __future__ import annotations
import json, socket, threading, time
from typing import Optional
import numpy as np

__all__ = ["WhisperNode"]


class _RNN:
    def __init__(self, hidden_size: int) -> None:
        self.W_h = np.zeros((hidden_size, hidden_size))
        self.W_i = np.zeros((hidden_size, 1))
        self.b   = np.zeros(hidden_size)
        self.h   = np.zeros(hidden_size)

    def step(self, x: float) -> np.ndarray:
        self.h = np.tanh(self.W_h @ self.h + self.W_i.flatten() * x + self.b)
        return self.h


class WhisperNode:
    MT_STATE = "state"
    MT_MIMIC = "mimic"

    def __init__(self, node_id: str = "w0", host: str = "0.0.0.0", port: int = 5100,
                 hidden_size: int = 8, light_mode: bool = False, enable_budding: bool = False) -> None:
        self.node_id       = node_id
        self.host          = host
        self.port          = port
        self.hidden_size   = hidden_size
        self.light_mode    = light_mode
        self.enable_budding = enable_budding
        self.running       = False
        self.rnn           = _RNN(hidden_size)
        self.inbox_states: list[tuple[str, np.ndarray]] = []
        self.inbox_mimic_data: dict[str, dict] = {}
        self.last_silence: Optional[float] = None
        self._sock: Optional[socket.socket] = None
        self._setup_socket()

    def _setup_socket(self) -> None:
        try:
            self._sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
            self._sock.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
            self._sock.setsockopt(socket.SOL_SOCKET, socket.SO_BROADCAST, 1)
            self._sock.bind((self.host, self.port))
            self._sock.settimeout(0.5)
        except Exception:
            pass

    def observe(self) -> None:
        for peer_id, weights in list(self.inbox_mimic_data.items()):
            try:
                self.rnn.W_h = np.array(weights["W_h"])
                self.rnn.W_i = np.array(weights["W_i"])
                self.rnn.b   = np.array(weights["b"])
            except Exception:
                pass

        input_val = np.random.randn() if not self.inbox_states else float(self.inbox_states[-1][1].mean())
        state = self.rnn.step(input_val)
        self.last_silence = time.time()
        if np.random.rand() < 0.5:
            self._broadcast({"type": self.MT_STATE, "node_id": self.node_id,
                             "state": state.tolist()})

    def _dispatch(self, msg: dict) -> None:
        if msg.get("type") == self.MT_STATE:
            peer = msg.get("node_id", "?")
            raw  = msg.get("state", [])
            self.inbox_states.append((peer, np.array(raw[:self.hidden_size])))
            if len(self.inbox_states) > 100:
                self.inbox_states = self.inbox_states[-50:]

    def _broadcast(self, msg: dict) -> None:
        if not self._sock: return
        try:
            data = json.dumps(msg).encode()
            self._sock.sendto(data, ("<broadcast>", self.port))
        except Exception:
            pass

    def stop(self) -> None:
        self.running = False
        if self._sock:
            try: self._sock.close()
            except Exception: pass
