"""src/security/git_ops.py — Git операции ARGOS"""
from __future__ import annotations
import subprocess
from datetime import datetime

__all__ = ["GitOps"]


class GitOps:
    def __init__(self, repo_path: str = ".") -> None:
        self.repo_path = repo_path

    def checkpoint(self, message: str = "Auto-evolution checkpoint") -> None:
        ts = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        try:
            subprocess.run(["git", "add", "-A"], cwd=self.repo_path, check=True, capture_output=True)
            subprocess.run(["git", "commit", "-m", f"{message} [{ts}]"],
                           cwd=self.repo_path, check=True, capture_output=True)
            print("💾 Точка сохранения создана.")
        except Exception as e:
            print(f"⚠️ Git не настроен: {e}")

    def rollback(self) -> None:
        try:
            subprocess.run(["git", "checkout", "."], cwd=self.repo_path, check=True, capture_output=True)
            print("🚨 Откат выполнен.")
        except Exception as e:
            print(f"⚠️ Откат не удался: {e}")
