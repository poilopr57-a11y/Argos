"""
src/security/git_guard.py — Git-безопасность ARGOS
===================================================
Проверяет .gitignore, сканирует секреты, устанавливает pre-commit хук.
"""
from __future__ import annotations

import os
import re
import stat
from pathlib import Path
from typing import Optional

__all__ = ["GitGuard", "REQUIRED_GITIGNORE"]

REQUIRED_GITIGNORE = [
    ".env", "*.db", "*.pyc", "__pycache__/", "*.log",
    "build/", "dist/", "*.egg-info/", ".venv/",
    "data/argos_model/*.pkl", "config/master.key",
    "config/master_auth.hash", "config/node_id",
]

_SECRET_PATTERNS = [
    (r'\d{8,}:[A-Za-z0-9_-]{30,}',                 "Telegram token"),
    (r'AIza[A-Za-z0-9_-]{30,}',                     "Google API key"),
    (r'sk-[A-Za-z0-9]{20,}',                        "OpenAI key"),
    (r'ghp_[A-Za-z0-9]{36,}',                       "GitHub PAT"),
    (r'xoxb-[0-9]+-[0-9]+-[A-Za-z0-9]+',           "Slack bot token"),
]

_HOOK_SCRIPT = """\
#!/bin/sh
# ARGOS pre-commit: scan for secrets
python3 -c "
import sys, re
from pathlib import Path
patterns = [r'\\d{8,}:[A-Za-z0-9_-]{30,}', r'AIza[A-Za-z0-9_-]{30,}', r'sk-[A-Za-z0-9]{20,}']
found = []
for f in Path('src').rglob('*.py'):
    text = f.read_text(errors='ignore')
    for p in patterns:
        if re.search(p, text):
            found.append(str(f))
if found:
    print('ARGOS: Possible secrets in:', found)
    sys.exit(1)
"
"""


class GitGuard:
    """Страж безопасности Git-репозитория ARGOS."""

    def __init__(self, repo_root: str = ".") -> None:
        self.repo_root = Path(repo_root).resolve()

    def check_gitignore(self) -> str:
        """Проверяет и дополняет .gitignore обязательными записями."""
        gi = self.repo_root / ".gitignore"
        if not gi.exists():
            return "⚠️ .gitignore не найден в репозитории"

        content = gi.read_text(encoding="utf-8")
        missing = [e for e in REQUIRED_GITIGNORE if e not in content]

        if not missing:
            return "✅ .gitignore в порядке"

        # Добавляем недостающие записи
        additions = "\n# ARGOS auto-added\n" + "\n".join(missing) + "\n"
        gi.write_text(content + additions, encoding="utf-8")
        return f"✅ .gitignore дополнен ({len(missing)} записей): {', '.join(missing[:3])}"

    def scan_secrets(self, scan_dir: str = "src") -> str:
        """Сканирует исходники на предмет утечки секретов."""
        scan_path = self.repo_root / scan_dir
        if not scan_path.exists():
            return f"⚠️ Директория {scan_dir} не найдена"

        found: list[str] = []
        for py_file in scan_path.rglob("*.py"):
            try:
                text = py_file.read_text(encoding="utf-8", errors="replace")
                for pattern, desc in _SECRET_PATTERNS:
                    if re.search(pattern, text):
                        found.append(f"{py_file.relative_to(self.repo_root)}: {desc}")
            except Exception:
                pass

        if not found:
            return f"✅ Секреты не обнаружены ({scan_dir}/)"
        return (
            f"🚨 Обнаружено потенциальных секретов: {len(found)}\n"
            + "\n".join(f"  • {f}" for f in found[:5])
        )

    def install_pre_commit_hook(self) -> str:
        """Устанавливает pre-commit хук в .git/hooks/."""
        hooks_dir = self.repo_root / ".git" / "hooks"
        if not hooks_dir.exists():
            return "⚠️ .git/hooks не найден — репозиторий не инициализирован"

        hook_path = hooks_dir / "pre-commit"
        hook_path.write_text(_HOOK_SCRIPT, encoding="utf-8")
        hook_path.chmod(hook_path.stat().st_mode | stat.S_IXUSR | stat.S_IXGRP)
        return f"✅ pre-commit хук установлен: {hook_path}"

    def status(self) -> str:
        """Краткий статус GitGuard."""
        gi = self.repo_root / ".gitignore"
        hook = self.repo_root / ".git" / "hooks" / "pre-commit"
        return (
            f"🛡️ GIT GUARD\n"
            f"  Репозиторий : {self.repo_root}\n"
            f"  .gitignore  : {'✅' if gi.exists() else '❌'}\n"
            f"  pre-commit  : {'✅' if hook.exists() else '❌'}"
        )

    def full_check(self) -> str:
        """Полная проверка безопасности."""
        parts = [
            "🛡️ GIT GUARD — полная проверка",
            self.check_gitignore(),
            self.scan_secrets(),
        ]
        return "\n".join(parts)

    def check_security(self) -> str:
        """Алиас для backward-compat."""
        return self.full_check()
