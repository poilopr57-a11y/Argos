"""
src/security/encryption.py — AES-256-GCM шифрование ARGOS
==========================================================
ArgosEncryption + ArgosShield (алиас обратной совместимости).
"""
from __future__ import annotations

import base64
import os
from typing import Optional

__all__ = ["ArgosEncryption", "ArgosShield"]

try:
    from cryptography.hazmat.primitives.ciphers.aead import AESGCM
    _CRYPTO_OK = True
except ImportError:
    _CRYPTO_OK = False


class ArgosEncryption:
    """
    AES-256-GCM шифрование для ARGOS.

    Использует cryptography.hazmat если установлено,
    иначе graceful degradation (base64).
    """

    KEY_SIZE = 32  # 256 бит

    def __init__(self, key: Optional[bytes] = None) -> None:
        if key:
            self._key = key[:self.KEY_SIZE].ljust(self.KEY_SIZE, b"\x00")
        else:
            master = os.environ.get("ARGOS_MASTER_KEY", "")
            if master:
                self._key = master.encode()[:self.KEY_SIZE].ljust(self.KEY_SIZE, b"\x00")
            else:
                self._key = os.urandom(self.KEY_SIZE)

    def encrypt(self, plaintext: str | bytes) -> str:
        """Шифрует данные, возвращает base64-строку."""
        data = plaintext.encode() if isinstance(plaintext, str) else plaintext
        if _CRYPTO_OK:
            nonce = os.urandom(12)
            ct = AESGCM(self._key).encrypt(nonce, data, None)
            return base64.b64encode(nonce + ct).decode()
        # Fallback
        return base64.b64encode(data).decode()

    def decrypt(self, ciphertext: str) -> str:
        """Расшифровывает base64-строку."""
        raw = base64.b64decode(ciphertext)
        if _CRYPTO_OK:
            nonce, ct = raw[:12], raw[12:]
            return AESGCM(self._key).decrypt(nonce, ct, None).decode()
        return raw.decode()

    def status(self) -> str:
        mode = "AES-256-GCM (cryptography)" if _CRYPTO_OK else "base64 fallback"
        return f"🔐 ArgosEncryption: {mode}"


# ArgosShield — алиас для обратной совместимости
class ArgosShield(ArgosEncryption):
    """Алиас ArgosEncryption для обратной совместимости."""
    pass
