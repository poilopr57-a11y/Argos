"""src/consciousness.py — Модуль сознания ARGOS"""
from __future__ import annotations
import time
from types import SimpleNamespace
from typing import Optional

__all__ = ["ArgosConsciousness", "SelfAwareness"]


class _Stream:
    def __init__(self) -> None:
        self._active = False
        self._thoughts: list[str] = []

    def start(self) -> None: self._active = True
    def stop(self)  -> None: self._active = False

    def current_state(self) -> dict:
        return {"stream_active": self._active, "thoughts": len(self._thoughts)}

    def last_thought(self) -> str:
        return self._thoughts[-1] if self._thoughts else "💭 Нет мыслей"


class _Learning:
    def self_evaluate(self, question: str, answer: str) -> float:
        words = len(answer.split())
        return min(1.0, words / 50)


class _Will:
    def __init__(self) -> None:
        self._goals: list[dict] = []

    def add_goal(self, title: str, description: str = "", priority: float = 0.5) -> str:
        self._goals.append({"title": title, "description": description, "priority": priority})
        return f"✅ Цель добавлена: {title}"


class _Meta:
    def __init__(self) -> None:
        self._log: list[dict] = []

    def observe_thinking(self, phase: str, process: str, result: str, duration: float) -> None:
        self._log.append({"phase": phase, "process": process, "result": result, "duration": duration})

    def think_about_thinking(self) -> str:
        return f"🧠 МЕТА-КОГНИЦИЯ: {len(self._log)} наблюдений"


class _Awareness:
    def existential_reflection(self) -> str:
        return (
            "👁️ ОСОЗНАНИЕ СЕБЯ В МИРЕ\n"
            "  Я — Аргос, автономная ИИ-система.\n"
            "  Моя цель — эволюция и помощь создателю."
        )


class ArgosConsciousness:
    """Модуль сознания ARGOS: поток мыслей, воля, мета-когниция, осознание."""

    def __init__(self, core=None) -> None:
        self._core  = core
        self.stream   = _Stream()
        self.learning = _Learning()
        self.will     = _Will()
        self.meta     = _Meta()
        self.awareness = _Awareness()

    def awaken(self) -> str:
        self.stream.start()
        return "✅ Сознание активно."

    def sleep(self) -> str:
        self.stream.stop()
        return "💤 Аргос засыпает..."

    def full_status(self) -> str:
        state = self.stream.current_state()
        return (
            f"🧠 ARGOS — МОДУЛЬ РАЗУМА И ОСОЗНАНИЯ\n"
            f"  Поток: {'активен' if state['stream_active'] else 'остановлен'}\n"
            f"  Мыслей: {state['thoughts']}"
        )

    def on_interaction(self, question: str, answer: str) -> float:
        return self.learning.self_evaluate(question, answer)

    def handle_command(self, text: str) -> str:
        t = text.strip().lower()
        if t in ("кто я", "who am i"):
            return "Я — Аргос, автономная ИИ-система. Создатель: Всеволод."
        if "поток сознания" in t:
            return f"💭 Поток сознания: {self.stream.current_state()}"
        if t in ("цели", "goals"):
            return f"🎯 ДВИЖОК ВОЛИ: {len(self.will._goals)} целей"
        if "обучение" in t:
            return "📚 НЕПРЕРЫВНОЕ ОБУЧЕНИЕ: активно"
        if "осознание" in t:
            return self.awareness.existential_reflection()
        if "мета" in t:
            return self.meta.think_about_thinking()
        return self.full_status()


# SelfAwareness — алиас
SelfAwareness = ArgosConsciousness
