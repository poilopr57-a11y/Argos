"""
src/skills/crypto_monitor/skill.py — Крипто-страж ARGOS
=========================================================
Мониторинг цен криптовалют с алертами через Telegram.
"""
from __future__ import annotations

import threading
import time
from typing import Optional

try:
    import requests
except ImportError:
    requests = None  # type: ignore

__all__ = ["CryptoSentinel"]

_COINS = {
    "bitcoin":  {"symbol": "BTC", "emoji": "₿"},
    "ethereum": {"symbol": "ETH", "emoji": "Ξ"},
}
_API_URL = "https://api.coingecko.com/api/v3/simple/price"


class CryptoSentinel:
    """Страж крипто-рынка — следит за изменениями цен и шлёт алерты."""

    def __init__(self, telegram_bot=None) -> None:
        self._bot = telegram_bot
        self.threshold: float = 5.0   # % изменение для алерта
        self._running = False
        self._thread: Optional[threading.Thread] = None

    # ── Публичный API ──────────────────────────────────────────────────────

    def get_prices(self) -> dict:
        """Получает текущие цены с CoinGecko."""
        if requests is None:
            return {}
        try:
            ids = ",".join(_COINS.keys())
            resp = requests.get(
                _API_URL,
                params={"ids": ids, "vs_currencies": "usd", "include_24hr_change": "true"},
                timeout=10,
            )
            resp.raise_for_status()
            raw = resp.json()
            result = {}
            for coin_id, info in _COINS.items():
                if coin_id in raw:
                    result[coin_id] = {
                        "symbol": info["symbol"],
                        "price":  float(raw[coin_id].get("usd", 0)),
                        "change": float(raw[coin_id].get("usd_24h_change", 0)),
                    }
            return result
        except Exception:
            return {}

    def check(self) -> list[str]:
        """Проверяет цены и возвращает список алертов."""
        prices = self.get_prices()
        alerts = []
        for coin_id, data in prices.items():
            change = data.get("change", 0)
            if abs(change) >= self.threshold:
                direction = "РОСТ 📈" if change > 0 else "ПАДЕНИЕ 📉"
                sym = data["symbol"]
                price = data["price"]
                alerts.append(
                    f"🚨 {sym} {direction} {change:+.1f}%\n"
                    f"   Цена: ${price:,.2f}"
                )
        return alerts

    def report(self) -> str:
        """Текстовый отчёт по текущим ценам."""
        prices = self.get_prices()
        if not prices:
            return "📡 Крипто-данные временно недоступны."
        lines = ["💰 КРИПТО-МОНИТОР:"]
        for coin_id, data in prices.items():
            sym    = data["symbol"]
            price  = data["price"]
            change = data["change"]
            icon   = "📈" if change >= 0 else "📉"
            lines.append(f"  {icon} {sym}: ${price:,.2f} ({change:+.1f}%)")
        return "\n".join(lines)

    def start_loop(self, interval_sec: int = 300) -> str:
        """Запускает фоновый мониторинг."""
        self._running = True
        bot_status = "подключён" if self._bot else "не подключён"

        def _loop():
            while self._running:
                try:
                    alerts = self.check()
                    for msg in alerts:
                        self._send_alert(msg)
                except Exception:
                    pass
                time.sleep(interval_sec)

        self._thread = threading.Thread(target=_loop, daemon=True)
        self._thread.start()
        return f"🛡️ Крипто-Страж запущен (интервал {interval_sec}с, бот {bot_status})"

    def stop(self) -> None:
        """Останавливает мониторинг."""
        self._running = False

    # ── Внутренние методы ──────────────────────────────────────────────────

    def _send_alert(self, message: str) -> None:
        """Отправляет алерт через доступный канал бота."""
        if not self._bot:
            return
        try:
            # Вариант 1: send_message(text)
            if hasattr(self._bot, "send_message"):
                self._bot.send_message(message)
                return
            # Вариант 2: send(text)
            if hasattr(self._bot, "send"):
                self._bot.send(message)
                return
            # Вариант 3: notify(text)
            if hasattr(self._bot, "notify"):
                self._bot.notify(message)
                return
            # Вариант 4: aiogram app.bot.send_message
            if hasattr(self._bot, "app") and hasattr(self._bot.app, "bot"):
                import asyncio
                user_id = getattr(self._bot, "user_id", None)
                if user_id:
                    asyncio.get_event_loop().run_until_complete(
                        self._bot.app.bot.send_message(chat_id=user_id, text=message)
                    )
        except Exception:
            pass
