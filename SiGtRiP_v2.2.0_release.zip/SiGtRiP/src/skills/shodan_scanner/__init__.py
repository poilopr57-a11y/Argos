"""
src/skills/shodan_scanner — Shodan API интеграция для ARGOS
"""
from __future__ import annotations

import os
from typing import Any, Optional

try:
    import requests as _requests
except ImportError:
    _requests = None  # type: ignore

__all__ = ["ShodanScanner"]

_BASE = "https://api.shodan.io"


class ShodanScanner:
    """Shodan API клиент для разведки сети."""

    def __init__(self, api_key: str = "") -> None:
        self._key = api_key or os.environ.get("SHODAN_API_KEY", "")

    def is_configured(self) -> bool:
        return bool(self._key)

    def _get(self, path: str, params: dict | None = None) -> dict:
        if not self._key:
            return {"error": "SHODAN_API_KEY is not configured"}
        if _requests is None:
            return {"error": "requests not installed"}
        try:
            p = dict(params or {})
            p["key"] = self._key
            resp = _requests.get(f"{_BASE}{path}", params=p, timeout=10)
            resp.raise_for_status()
            return resp.json()
        except Exception as e:
            return {"error": f"error:{e}"}

    def my_ip(self) -> str:
        result = self._get("/tools/myip")
        if "error" in result:
            return result["error"]
        return str(result)

    def search(self, query: str, page: int = 1) -> dict:
        return self._get("/shodan/host/search", {"query": query, "page": page})

    def host(self, ip: str) -> dict:
        return self._get(f"/shodan/host/{ip}")
