"""llm_dialog — навык диалога двух LLM-моделей (по мотивам habr.com/ru/articles/1013178/)."""
from .skill import LLMDialog

__all__ = ["LLMDialog"]
