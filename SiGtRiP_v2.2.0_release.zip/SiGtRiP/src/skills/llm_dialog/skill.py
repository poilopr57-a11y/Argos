"""
src/skills/llm_dialog/skill.py
==============================
Навык «Диалог двух LLM» для ARGOS Universal OS.

Идея: два Ollama-движка (или любых провайдера) ведут диалог без участия человека.
Интерфейс: текстовые команды ARGOS → Telegram → GUI.

Команды
-------
диалог помощь                              — список команд
диалог старт <тема>                        — запустить диалог (модели из ENV)
диалог старт <тема> --m1 gemma3 --m2 llama3
диалог старт <тема> --раунды 5 --роль1 "эксперт" --роль2 "скептик"
диалог статус                              — текущий раунд / состояние
диалог стоп                                — прервать диалог
диалог история                             — последние 20 реплик
диалог очистить                            — сброс истории

Основана на статье rtmntnv (Хабр, март 2025):
https://habr.com/ru/articles/1013178/
"""
from __future__ import annotations

import re
import threading
import time
from dataclasses import dataclass, field
from typing import Callable, List, Optional

import requests

# ──────────────────────────────────────────────────────────────────
# Дефолтные параметры
# ──────────────────────────────────────────────────────────────────
_DEFAULT_MODEL_1 = "llama3"
_DEFAULT_MODEL_2 = "gemma3"
_DEFAULT_ROUNDS  = 3
_DEFAULT_TIMEOUT = 120          # секунды ожидания одного ответа
_MAX_HISTORY_PER_MODEL = 20     # последние N сообщений на контекст
_OLLAMA_URL = "http://localhost:11434/api/chat"

# ──────────────────────────────────────────────────────────────────
# Структуры данных
# ──────────────────────────────────────────────────────────────────

@dataclass
class DialogMessage:
    role: str                   # "system" | "user" | "assistant" | "error"
    content: str
    model: str = ""
    timestamp: str = ""
    round_num: int = 0
    is_bot: bool = False

    def formatted(self) -> str:
        ts = self.timestamp or time.strftime("%H:%M:%S")
        if self.role == "error":
            return f"❌ [{ts}] ОШИБКА: {self.content}"
        if not self.is_bot:
            return f"ℹ️  [{ts}] {self.content}"
        tag = "🔵" if self.round_num % 2 == 1 else "🟢"
        return f"{tag} [{ts}] {self.model} (раунд {self.round_num}):\n{self.content}"


@dataclass
class ModelContext:
    """Хранит системное сообщение и скользящую историю одной модели."""
    role_desc: str = ""
    history: List[dict] = field(default_factory=list)

    def system_content(self, topic: str) -> str:
        base = f"Тема диалога: {topic}"
        if self.role_desc:
            return f"Ты играешь роль: {self.role_desc}. {base}"
        return base

    def build_messages(self, topic: str) -> List[dict]:
        msgs: List[dict] = [{"role": "system", "content": self.system_content(topic)}]
        msgs.extend(self.history[-_MAX_HISTORY_PER_MODEL:])
        return msgs

    def add_own(self, content: str) -> None:
        self.history.append({"role": "assistant", "content": content})
        self._trim()

    def add_partner(self, content: str) -> None:
        self.history.append({"role": "user", "content": content})
        self._trim()

    def _trim(self) -> None:
        if len(self.history) > _MAX_HISTORY_PER_MODEL:
            self.history = self.history[-_MAX_HISTORY_PER_MODEL:]


# ──────────────────────────────────────────────────────────────────
# Ядро диалога
# ──────────────────────────────────────────────────────────────────

class LLMDialog:
    """Управляет диалогом двух LLM-моделей через Ollama API."""

    def __init__(self, core=None):
        self.core = core
        self._lock = threading.Lock()
        self._thread: Optional[threading.Thread] = None
        self._active = False
        self._messages: List[DialogMessage] = []
        self._current_round = 0
        self._total_rounds = 0
        self._model1 = _DEFAULT_MODEL_1
        self._model2 = _DEFAULT_MODEL_2
        self._topic = ""
        self._on_message: Optional[Callable[[DialogMessage], None]] = None

    # ── публичный API ──────────────────────────────────────────────

    def start(
        self,
        topic: str,
        model1: str = _DEFAULT_MODEL_1,
        model2: str = _DEFAULT_MODEL_2,
        rounds: int = _DEFAULT_ROUNDS,
        role1: str = "",
        role2: str = "",
        timeout: int = _DEFAULT_TIMEOUT,
        on_message: Optional[Callable[[DialogMessage], None]] = None,
    ) -> str:
        """Запуск диалога в фоновом потоке. Возвращает строку-статус."""
        with self._lock:
            if self._active:
                return "⚠️ Диалог уже запущен. Используй «диалог стоп» для остановки."
            if model1 == model2:
                return "❌ Выбери две разные модели."
            if not topic.strip():
                return "❌ Укажи тему диалога."

            self._active = True
            self._messages.clear()
            self._current_round = 0
            self._total_rounds = rounds
            self._model1 = model1
            self._model2 = model2
            self._topic = topic
            self._on_message = on_message

        ctx1 = ModelContext(role_desc=role1)
        ctx2 = ModelContext(role_desc=role2)

        self._thread = threading.Thread(
            target=self._run,
            args=(topic, model1, model2, rounds, timeout, ctx1, ctx2),
            daemon=True,
        )
        self._thread.start()
        return (
            f"🚀 Диалог запущен!\n"
            f"  Модели  : {model1} 🔵 vs {model2} 🟢\n"
            f"  Тема    : {topic}\n"
            f"  Раундов : {rounds}\n"
            f"  Таймаут : {timeout} сек/ответ"
        )

    def stop(self) -> str:
        with self._lock:
            if not self._active:
                return "ℹ️ Диалог не запущен."
            self._active = False
        return "🛑 Диалог остановлен."

    def status(self) -> str:
        with self._lock:
            if not self._active:
                return "💤 Диалог не активен."
            pct = int(self._current_round / max(self._total_rounds, 1) * 100)
            bar = "█" * (pct // 10) + "░" * (10 - pct // 10)
            return (
                f"📊 ДИАЛОГ — СТАТУС\n"
                f"  Модели : {self._model1} vs {self._model2}\n"
                f"  Раунд  : {self._current_round}/{self._total_rounds}\n"
                f"  [{bar}] {pct}%\n"
                f"  Тема   : {self._topic[:80]}"
            )

    def history(self, last: int = 10) -> str:
        with self._lock:
            msgs = list(self._messages[-last:])
        if not msgs:
            return "📭 История пуста."
        return "\n\n".join(m.formatted() for m in msgs)

    def clear(self) -> str:
        with self._lock:
            if self._active:
                return "⚠️ Нельзя очистить историю во время активного диалога."
            self._messages.clear()
            self._current_round = 0
        return "🗑️ История очищена."

    def handle_command(self, text: str) -> Optional[str]:
        """Разбирает команду пользователя и возвращает ответ или None."""
        t = text.strip().lower()

        if not (t.startswith("диалог") or t.startswith("llm диалог")):
            return None

        # Нормализация: убираем префикс
        for prefix in ("llm диалог", "диалог"):
            if t.startswith(prefix):
                t = t[len(prefix):].strip()
                break

        if not t or t == "помощь" or t == "help":
            return self._help()

        if t == "статус":
            return self.status()

        if t == "стоп" or t == "stop":
            return self.stop()

        if t == "история" or t == "history":
            return self.history()

        if t == "очистить" or t == "clear":
            return self.clear()

        if t.startswith("старт") or t.startswith("start"):
            return self._parse_start(text)

        return self._help()

    # ── внутренние методы ──────────────────────────────────────────

    def _parse_start(self, raw_text: str) -> str:
        """Парсим: диалог старт <тема> [--m1 X] [--m2 Y] [--раунды N] [--роль1 X] [--роль2 Y]"""
        # убираем 'диалог старт'
        text = re.sub(r"(?:llm\s+)?диалог\s+(?:старт|start)\s*", "", raw_text, flags=re.I).strip()

        def _extract(flag: str, default: str) -> str:
            m = re.search(rf"--{flag}\s+([^\-][^\s]*(?:\s[^\-][^\s]*)*?)(?=\s+--|$)", text, re.I)
            return m.group(1).strip() if m else default

        def _extract_int(flag: str, default: int) -> int:
            pattern = rf"--(?:{flag})\s+(\d+)"
            m = re.search(pattern, text, re.I)
            if m and m.group(1):
                return int(m.group(1))
            return default

        model1  = _extract("m1", _DEFAULT_MODEL_1)
        model2  = _extract("m2", _DEFAULT_MODEL_2)
        role1   = _extract("роль1|role1", "")
        role2   = _extract("роль2|role2", "")
        rounds  = _extract_int("раунды|rounds", _DEFAULT_ROUNDS)
        timeout = _extract_int("таймаут|timeout", _DEFAULT_TIMEOUT)

        # Тема — всё до первого флага
        topic_match = re.match(r"^(.*?)(?:\s+--|$)", text, re.DOTALL)
        topic = topic_match.group(1).strip() if topic_match else text.strip()

        if not topic:
            return "❌ Укажи тему. Пример: диалог старт Что такое сознание? --раунды 4"

        return self.start(
            topic=topic,
            model1=model1,
            model2=model2,
            rounds=rounds,
            role1=role1,
            role2=role2,
            timeout=timeout,
        )

    def _run(
        self,
        topic: str,
        model1: str,
        model2: str,
        rounds: int,
        timeout: int,
        ctx1: ModelContext,
        ctx2: ModelContext,
    ) -> None:
        self._emit(DialogMessage(
            role="system",
            content=f"Диалог начался: {model1} 🔵 vs {model2} 🟢\nТема: {topic}",
            timestamp=time.strftime("%H:%M:%S"),
        ))

        # Первый промпт для модели 1
        ctx1.add_partner(f"Начнём диалог. {topic}")

        for rnd in range(1, rounds + 1):
            with self._lock:
                if not self._active:
                    break
                self._current_round = rnd

            # ── Ход модели 1 ─────────────────────────────────────
            resp1 = self._call(model1, ctx1.build_messages(topic), timeout)
            if resp1 is None:
                self._emit(DialogMessage(
                    role="error", content=f"Модель {model1} не ответила (таймаут).",
                    timestamp=time.strftime("%H:%M:%S"),
                ))
                break

            msg1 = DialogMessage(
                role="assistant", content=resp1, model=model1,
                timestamp=time.strftime("%H:%M:%S"), round_num=rnd, is_bot=True,
            )
            ctx1.add_own(resp1)
            ctx2.add_partner(resp1)
            self._emit(msg1)

            with self._lock:
                if not self._active:
                    break

            # ── Ход модели 2 ─────────────────────────────────────
            resp2 = self._call(model2, ctx2.build_messages(topic), timeout)
            if resp2 is None:
                self._emit(DialogMessage(
                    role="error", content=f"Модель {model2} не ответила (таймаут).",
                    timestamp=time.strftime("%H:%M:%S"),
                ))
                break

            msg2 = DialogMessage(
                role="assistant", content=resp2, model=model2,
                timestamp=time.strftime("%H:%M:%S"), round_num=rnd, is_bot=True,
            )
            ctx2.add_own(resp2)
            ctx1.add_partner(resp2)
            self._emit(msg2)

            time.sleep(0.5)

        with self._lock:
            finished = self._current_round
            self._active = False

        self._emit(DialogMessage(
            role="system",
            content=f"✅ Диалог завершён. Всего раундов: {finished}/{rounds}.",
            timestamp=time.strftime("%H:%M:%S"),
        ))

    def _call(self, model: str, messages: List[dict], timeout: int) -> Optional[str]:
        """HTTP-запрос к Ollama /api/chat. Возвращает текст или None при ошибке."""
        # Фильтруем пустые сообщения
        clean = [m for m in messages if m.get("content", "").strip()]
        if not clean:
            return None
        payload = {
            "model": model,
            "messages": clean,
            "stream": False,
            "options": {"num_predict": 1024},
        }
        try:
            resp = requests.post(_OLLAMA_URL, json=payload, timeout=timeout)
            resp.raise_for_status()
            data = resp.json()
            content = data.get("message", {}).get("content", "").strip()
            return content if content else None
        except Exception:
            # Если есть ядро ARGOS — пробуем через него
            if self.core and hasattr(self.core, "_ask_ollama"):
                try:
                    system_msg = next(
                        (m["content"] for m in clean if m["role"] == "system"), ""
                    )
                    user_msgs = [m["content"] for m in clean if m["role"] != "system"]
                    prompt = "\n".join(user_msgs)
                    result = self.core._ask_ollama(system_msg, prompt)
                    return result
                except Exception:
                    pass
            return None

    def _emit(self, msg: DialogMessage) -> None:
        with self._lock:
            self._messages.append(msg)
        if self._on_message:
            try:
                self._on_message(msg)
            except Exception:
                pass

    @staticmethod
    def _help() -> str:
        return (
            "🤖 ДИАЛОГ ДВУХ LLM\n"
            "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n"
            "Запускает две Ollama-модели, которые общаются друг с другом.\n\n"
            "Команды:\n"
            "  диалог старт <тема>          — запуск с дефолтными моделями\n"
            "  диалог старт <тема> --m1 gemma3 --m2 llama3\n"
            "  диалог старт <тема> --раунды 5\n"
            "  диалог старт <тема> --роль1 «эксперт» --роль2 «скептик»\n"
            "  диалог старт <тема> --таймаут 60\n"
            "  диалог статус                — прогресс текущего диалога\n"
            "  диалог история               — последние 10 реплик\n"
            "  диалог стоп                  — остановить диалог\n"
            "  диалог очистить              — сбросить историю\n\n"
            "Пример:\n"
            "  диалог старт Что такое сознание? --m1 phi3 --m2 mistral --раунды 4"
        )


# ── ARGOS SkillLoader entrypoints ─────────────────────────────────

_DIALOG: Optional[LLMDialog] = None

SKILL_TRIGGERS = [
    "диалог старт",
    "диалог стоп",
    "диалог статус",
    "диалог история",
    "диалог очистить",
    "диалог помощь",
    "llm диалог",
    "запусти диалог",
    "два llm",
    "диалог моделей",
]


def _get_dialog(core=None) -> LLMDialog:
    global _DIALOG
    if _DIALOG is None:
        _DIALOG = LLMDialog(core=core)
    elif core is not None and _DIALOG.core is None:
        _DIALOG.core = core
    return _DIALOG


def handle(text: str, core=None) -> Optional[str]:
    """Entrypoint для ARGOS SkillLoader."""
    tl = text.lower().strip()
    if not any(tl.startswith(t) or t in tl for t in SKILL_TRIGGERS):
        return None
    dlg = _get_dialog(core)
    return dlg.handle_command(text)


def execute(core=None, args: str = "") -> str:
    """Entrypoint для прямого вызова."""
    dlg = _get_dialog(core)
    return dlg.handle_command(f"диалог {args}")
