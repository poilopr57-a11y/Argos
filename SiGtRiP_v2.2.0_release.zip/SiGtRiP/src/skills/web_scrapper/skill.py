"""src/skills/web_scrapper/skill.py — Веб-поиск через DuckDuckGo"""
from __future__ import annotations
try:
    import requests
    from bs4 import BeautifulSoup
    _DEPS_OK = True
except ImportError:
    _DEPS_OK = False

__all__ = ["ArgosScrapper"]

_DDG_URL = "https://html.duckduckgo.com/html/"


class ArgosScrapper:
    """Быстрый веб-поиск через DuckDuckGo HTML."""

    def quick_search(self, query: str, max_results: int = 3) -> str:
        if not _DEPS_OK:
            return "❌ requests / beautifulsoup4 не установлены"
        try:
            from urllib.parse import quote_plus
            encoded = quote_plus(query)
            url = f"{_DDG_URL}?q={encoded}"
            resp = requests.get(url, headers={"User-Agent": "ArgosBot/2.0"}, timeout=10)
            if resp.status_code != 200:
                return f"❌ Ошибка доступа: HTTP {resp.status_code}"
            soup = BeautifulSoup(resp.text, "html.parser")

            # Пробуем основной селектор
            snippets = [a.get_text(strip=True)
                        for a in soup.find_all("a", class_="result__snippet")]
            # Резервный
            if not snippets:
                snippets = [d.get_text(strip=True)
                            for d in soup.find_all("div", class_="result__body")]

            if not snippets:
                return f"🔍 Поиск «{query}» не дал результатов"

            items = snippets[:max_results]
            return f"🌐 Данные из глобальной сети:\n" + " | ".join(items)

        except Exception as e:
            return f"❌ Сбой сетевого сканирования: {e}"
