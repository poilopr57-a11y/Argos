from .skill import ArgosScrapper
__all__ = ["ArgosScrapper"]
