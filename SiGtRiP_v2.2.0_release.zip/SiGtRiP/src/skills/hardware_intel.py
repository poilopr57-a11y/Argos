"""src/skills/hardware_intel.py — Диагностика железа (skill)"""
from ardware_intel import execute, handle, SKILL_TRIGGERS
__all__ = ["execute", "handle", "SKILL_TRIGGERS"]
