"""
src/skills/huggingface_ai — HuggingFace Inference API для ARGOS
"""
from __future__ import annotations

import os
from typing import Any

try:
    import requests as _requests
except ImportError:
    _requests = None  # type: ignore

__all__ = ["HuggingFaceAI"]

_DEFAULT_MODEL = "mistralai/Mistral-7B-Instruct-v0.2"
_EMBED_MODEL   = "sentence-transformers/all-MiniLM-L6-v2"
_BASE = "https://api-inference.huggingface.co/models"


class HuggingFaceAI:
    """HuggingFace Inference API клиент."""

    def __init__(self, model: str = "") -> None:
        self._token = os.environ.get("HUGGINGFACE_TOKEN", "")
        self.model  = model or os.environ.get("HUGGINGFACE_MODEL", _DEFAULT_MODEL)

    def is_configured(self) -> bool:
        return bool(self._token)

    def _headers(self) -> dict:
        return {"Authorization": f"Bearer {self._token}"}

    def ask(self, prompt: str, max_new_tokens: int = 200) -> str:
        if not self._token:
            raise ValueError("HUGGINGFACE_TOKEN is not set")
        if _requests is None:
            raise RuntimeError("requests not installed")
        resp = _requests.post(
            f"{_BASE}/{self.model}",
            headers=self._headers(),
            json={"inputs": prompt, "parameters": {"max_new_tokens": max_new_tokens}},
            timeout=30,
        )
        resp.raise_for_status()
        data = resp.json()
        if isinstance(data, list) and data:
            return data[0].get("generated_text", str(data[0]))
        return str(data)

    def embed(self, text: str) -> list[float]:
        if not self._token:
            raise ValueError("HUGGINGFACE_TOKEN is not set")
        if _requests is None:
            raise RuntimeError("requests not installed")
        resp = _requests.post(
            f"{_BASE}/{_EMBED_MODEL}",
            headers=self._headers(),
            json={"inputs": text},
            timeout=30,
        )
        resp.raise_for_status()
        data = resp.json()
        if isinstance(data, list) and data and isinstance(data[0], (int, float)):
            return [float(x) for x in data]
        return []
