"""src/skills/net_scanner/skill.py — Сетевой призрак"""
from __future__ import annotations
import socket
from typing import Optional

__all__ = ["NetGhost"]

class NetGhost:
    """Сканер сети ARGOS."""
    name = "NetGhost"
    version = "1.2.0"

    def __init__(self, core=None) -> None:
        self._core = core

    def on_load(self) -> str:   return "🕵️ NetGhost загружен"
    def on_unload(self) -> str: return "🕵️ NetGhost выгружен"
    def health_check(self) -> bool: return True

    def scan_ports(self, host: str, ports: list[int] | None = None,
                   timeout: float = 0.5) -> dict:
        ports = ports or [22, 80, 443, 8080, 8443, 3306, 5432]
        open_ports = []
        for p in ports:
            try:
                with socket.create_connection((host, p), timeout=timeout):
                    open_ports.append(p)
            except Exception:
                pass
        return {"host": host, "open_ports": open_ports, "scanned": len(ports)}

    def scan_network(self, subnet: str = "192.168.1") -> list[str]:
        alive = []
        for i in range(1, 255):
            host = f"{subnet}.{i}"
            try:
                socket.create_connection((host, 80), timeout=0.1)
                alive.append(host)
            except Exception:
                pass
        return alive

    def handle(self, text: str) -> Optional[str]:
        t = text.lower()
        if any(k in t for k in ("сканировать сеть","scan network","network scan")):
            return "🔍 Запуск сканирования сети..."
        if any(k in t for k in ("scan port","сканировать порт")):
            return "🔍 Сканирование портов..."
        return None
