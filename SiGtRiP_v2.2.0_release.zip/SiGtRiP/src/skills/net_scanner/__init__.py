from .skill import NetGhost
__all__ = ["NetGhost"]
