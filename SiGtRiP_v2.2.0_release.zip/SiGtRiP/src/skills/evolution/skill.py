"""
src/skills/evolution/skill.py — Эволюция навыков ARGOS
======================================================
ArgosEvolution с жёстким code-gate: code review + unit-test
перед применением патча.
"""
from __future__ import annotations

import ast
import importlib.util
import os
import subprocess
import sys
import tempfile
from pathlib import Path
from typing import Optional

__all__ = ["ArgosEvolution", "SKILLS_DIR", "TESTS_GEN_DIR"]

SKILLS_DIR    = "src/skills"
TESTS_GEN_DIR = "tests/generated"


class ArgosEvolution:
    """
    Движок эволюции навыков ARGOS.

    apply_patch() пропускает новый код через:
    1. Code Review (_review_patch)
    2. Unit-тест (_run_unit_test)
    3. Только при прохождении обоих — сохраняет файл
    """

    def __init__(self, ai_core=None) -> None:
        self._core = ai_core

    # ── Публичный API ──────────────────────────────────────────────────────

    def apply_patch(
        self,
        skill_name: str,
        code: str,
        test_code: str = "",
    ) -> str:
        """
        Применяет патч навыка с прохождением gate.

        Args:
            skill_name: Имя навыка (без .py).
            code:       Исходный код навыка.
            test_code:  Код unit-теста для валидации.

        Returns:
            Строка с результатом: успех или причина отказа.
        """
        # ── Gate 1: синтаксис ──────────────────────────────────────────
        try:
            ast.parse(code)
        except SyntaxError as e:
            return f"❌ Синтаксическая ошибка: {e}"

        # ── Gate 2: Code Review ────────────────────────────────────────
        approved, review_msg = self._review_patch(skill_name, code)
        if not approved:
            return f"❌ Code Review не пройден: {review_msg}"

        # ── Gate 3: Unit-тест ──────────────────────────────────────────
        if test_code:
            passed, test_msg = self._run_unit_test(skill_name, code, test_code)
            if not passed:
                return f"❌ unit-тест не пройден: {test_msg}"

        # ── Применяем патч ─────────────────────────────────────────────
        skills_dir = Path(SKILLS_DIR)
        tests_dir  = Path(TESTS_GEN_DIR)
        skills_dir.mkdir(parents=True, exist_ok=True)
        tests_dir.mkdir(parents=True, exist_ok=True)

        skill_path = skills_dir / f"{skill_name}.py"
        skill_path.write_text(code, encoding="utf-8")

        if test_code:
            test_path = tests_dir / f"test_skill_{skill_name}.py"
            test_path.write_text(test_code, encoding="utf-8")

        return f"✅ Навык «{skill_name}» внедрён в {skill_path}"

    def generate_skill(self, description: str) -> str:
        """Генерирует код навыка через LLM-ядро."""
        if not self._core:
            return f"# Заглушка навыка: {description}\ndef handle(text):\n    return None\n"
        try:
            ask = getattr(self._core, "_ask_gemini", None) or getattr(self._core, "_ask_ollama", None)
            if ask:
                prompt = (
                    f"Напиши Python-навык для ARGOS. Описание: {description}\n"
                    f"Требования: функция handle(text) -> Optional[str], "
                    f"список SKILL_TRIGGERS, класс с методами.\n"
                    f"Верни только код без объяснений."
                )
                result = ask("Ты Python-разработчик.", prompt)
                if result:
                    return result
        except Exception:
            pass
        return f"# Навык: {description}\ndef handle(text):\n    return None\n"

    # ── Внутренние методы ──────────────────────────────────────────────────

    def _review_patch(self, skill_name: str, code: str) -> tuple[bool, str]:
        """
        Code Review через LLM или базовые проверки.
        Returns (approved, reason).
        """
        # Базовые безопасные проверки
        dangerous = ["os.system", "subprocess.call", "__import__", "eval(", "exec("]
        for d in dangerous:
            if d in code and "import" not in code.split(d)[0].split("\n")[-1]:
                return False, f"Потенциально опасный код: {d}"

        # LLM review если доступен
        if self._core:
            try:
                ask = getattr(self._core, "_ask_gemini", None)
                if ask:
                    verdict = ask(
                        "Ты code reviewer.",
                        f"Проверь безопасность кода навыка «{skill_name}».\n"
                        f"Ответь только: APPROVED или REJECTED: причина\n\n{code[:2000]}"
                    )
                    if verdict and "REJECTED" in verdict.upper():
                        reason = verdict.split(":", 1)[-1].strip()
                        return False, reason
                    return True, "LLM approved"
            except Exception:
                pass

        return True, "базовые проверки пройдены"

    def _run_unit_test(
        self,
        skill_name: str,
        skill_code: str,
        test_code: str,
    ) -> tuple[bool, str]:
        """
        Запускает unit-тест в изолированном окружении.
        Returns (passed, output).
        """
        with tempfile.TemporaryDirectory() as tmpdir:
            tmp = Path(tmpdir)

            # Пишем навык как skill_under_test.py
            skill_file = tmp / "skill_under_test.py"
            skill_file.write_text(skill_code, encoding="utf-8")

            # Пишем тест
            test_file = tmp / f"test_{skill_name}.py"
            test_file.write_text(test_code, encoding="utf-8")

            # Запускаем pytest / unittest
            try:
                result = subprocess.run(
                    [sys.executable, "-m", "pytest", str(test_file), "-v", "--tb=short", "-q"],
                    capture_output=True,
                    text=True,
                    timeout=30,
                    cwd=tmpdir,
                )
                if result.returncode == 0:
                    return True, "tests passed"
                return False, (result.stdout + result.stderr)[:300]
            except subprocess.TimeoutExpired:
                return False, "тест превысил таймаут 30с"
            except Exception as e:
                return False, str(e)
