"""src/argos_model.py — Собственная ML-модель ARGOS"""
from __future__ import annotations
import json, os, time
from pathlib import Path
from typing import Optional

__all__ = ["ArgosOwnModel"]

_MODEL_DIR = Path("data/argos_model")
_TRAINING_CLASSES = ["ai","build","file","git","iot","memory","network","skill","system"]

_TRAINING_DATA = {
    "ai":      ["спроси модель","gemini","ollama","gpt","ai ответ","нейросеть"],
    "build":   ["собери apk","buildozer","pyinstaller","сборка","build"],
    "file":    ["создай файл","читай файл","удали файл","список файлов"],
    "git":     ["git статус","git коммит","git пуш","git pull"],
    "iot":     ["mqtt","zigbee","lora","умный дом","датчик","modbus"],
    "memory":  ["запомни","вспомни","память","факт","заметка"],
    "network": ["сканировать сеть","ip","ping","порт","p2p"],
    "skill":   ["навык","загрузи навык","список навыков","плагин"],
    "system":  ["статус системы","cpu","ram","диск","температура","процессы"],
}


class ArgosOwnModel:
    def __init__(self, core=None, model_dir: str = str(_MODEL_DIR)) -> None:
        self._core      = core
        self._model_dir = Path(model_dir)
        self._clf       = None
        self._vec       = None
        self._meta: dict = {}
        self._load()

    # ── Public API ────────────────────────────────────────────────────────

    def predict(self, text: str) -> str:
        if self._clf and self._vec:
            try:
                x = self._vec.transform([text.lower()])
                return self._clf.predict(x)[0]
            except Exception:
                pass
        return self._simple_classify(text)

    def train(self) -> str:
        try:
            from sklearn.feature_extraction.text import TfidfVectorizer
            from sklearn.linear_model import LogisticRegression
            import numpy as np

            texts, labels = [], []
            for cls, samples in _TRAINING_DATA.items():
                for s in samples:
                    texts.append(s.lower())
                    labels.append(cls)
            # Augment
            for cls, samples in _TRAINING_DATA.items():
                for s in samples:
                    texts.append((s + " помощь").lower())
                    labels.append(cls)

            self._vec = TfidfVectorizer(analyzer="char_wb", ngram_range=(2, 4))
            X = self._vec.fit_transform(texts)
            self._clf = LogisticRegression(max_iter=500)
            self._clf.fit(X, labels)

            # Evaluate
            preds = self._clf.predict(X)
            acc = float(np.mean(np.array(preds) == np.array(labels)))

            # Save meta
            self._model_dir.mkdir(parents=True, exist_ok=True)
            meta = {
                "version":    f"1.4.0+{os.urandom(4).hex()}",
                "trained_at": time.strftime("%Y-%m-%dT%H:%M:%S"),
                "accuracy":   acc,
                "samples":    len(texts),
                "classes":    sorted(set(labels)),
                "git_hash":   "",
            }
            (self._model_dir / "model_meta.json").write_text(
                json.dumps(meta, indent=2), encoding="utf-8")
            # Append to history
            hist_path = self._model_dir / "training_history.jsonl"
            with open(hist_path, "a", encoding="utf-8") as f:
                f.write(json.dumps(meta) + "\n")
            self._meta = meta
            return (f"✅ Модель обучена: accuracy={acc:.2%}, "
                    f"samples={len(texts)}, classes={len(set(labels))}")
        except ImportError:
            return "⚠️ scikit-learn не установлен"
        except Exception as e:
            return f"❌ Ошибка обучения: {e}"

    def status(self) -> str:
        if self._clf:
            acc = self._meta.get("accuracy", 0)
            ver = self._meta.get("version", "?")
            return f"🤖 model ok | v{ver} | acc={acc:.0%}"
        return "⚠️ Модель не обучена"

    # ── Private ───────────────────────────────────────────────────────────

    def _load(self) -> None:
        meta_path = self._model_dir / "model_meta.json"
        if meta_path.exists():
            try:
                self._meta = json.loads(meta_path.read_text())
            except Exception:
                pass

    def _simple_classify(self, text: str) -> str:
        t = text.lower()
        for cls, keywords in _TRAINING_DATA.items():
            if any(k in t for k in keywords):
                return cls
        return "system"
