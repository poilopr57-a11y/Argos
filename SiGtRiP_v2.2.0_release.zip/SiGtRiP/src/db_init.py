"""src/db_init.py — Инициализация SQLite БД ARGOS"""
from __future__ import annotations
import os, sqlite3, threading
from pathlib import Path

DB_PATH = "data/argos.db"
__all__ = ["init_db", "ArgosDB"]


def init_db(path: str = DB_PATH) -> sqlite3.Connection:
    Path(path).parent.mkdir(parents=True, exist_ok=True)
    conn = sqlite3.connect(path, check_same_thread=False)
    c = conn.cursor()
    c.execute("""CREATE TABLE IF NOT EXISTS chat_history (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        timestamp TEXT DEFAULT (datetime('now','localtime')),
        role TEXT NOT NULL, state TEXT, message TEXT NOT NULL)""")
    c.execute("""CREATE TABLE IF NOT EXISTS command_log (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        timestamp TEXT DEFAULT (datetime('now','localtime')),
        command TEXT NOT NULL, result TEXT, source TEXT DEFAULT 'gui')""")
    c.execute("""CREATE TABLE IF NOT EXISTS skills (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        name TEXT UNIQUE NOT NULL, description TEXT,
        created_at TEXT DEFAULT (datetime('now','localtime')), active INTEGER DEFAULT 1)""")
    c.execute("""CREATE TABLE IF NOT EXISTS geo_log (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        timestamp TEXT DEFAULT (datetime('now','localtime')),
        city TEXT, country TEXT, isp TEXT, ip TEXT)""")
    conn.commit()
    return conn


class ArgosDB:
    def __init__(self, path: str = DB_PATH):
        self.conn = init_db(path)
        self._lock = threading.RLock()

    def _execute(self, q: str, p: tuple = (), commit: bool = False):
        with self._lock:
            cur = self.conn.execute(q, p)
            if commit: self.conn.commit()
            return cur

    def log_chat(self, role: str, message: str, state: str = None):
        self._execute("INSERT INTO chat_history (role,state,message) VALUES(?,?,?)",
                      (role, state, message), commit=True)

    def log_command(self, command: str, result: str, source: str = "gui"):
        self._execute("INSERT INTO command_log (command,result,source) VALUES(?,?,?)",
                      (command, result, source), commit=True)

    def log_geo(self, city: str, country: str, isp: str = "", ip: str = ""):
        self._execute("INSERT INTO geo_log (city,country,isp,ip) VALUES(?,?,?,?)",
                      (city, country, isp, ip), commit=True)

    def get_history(self, limit: int = 20) -> list:
        return self._execute(
            "SELECT timestamp,role,state,message FROM chat_history ORDER BY id DESC LIMIT ?",
            (limit,)).fetchall()

    def format_history(self, limit: int = 10) -> str:
        rows = self.get_history(limit)
        if not rows: return "📭 История пуста."
        lines = [f"📜 ИСТОРИЯ (последние {limit}):"]
        for ts, role, state, msg in reversed(rows):
            icon = "👤" if role == "user" else "👁️"
            st = f"[{state}] " if state else ""
            lines.append(f"  {ts} {icon} {st}{msg[:80]}")
        return "\n".join(lines)

    def search_history(self, query: str) -> list:
        return self._execute(
            "SELECT timestamp,role,message FROM chat_history WHERE message LIKE ? ORDER BY id DESC LIMIT 10",
            (f"%{query}%",)).fetchall()

    def close(self):
        with self._lock: self.conn.close()
