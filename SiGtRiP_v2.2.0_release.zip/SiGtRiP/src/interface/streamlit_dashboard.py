"""
src/interface/streamlit_dashboard.py — Streamlit дашборд ARGOS
==============================================================
"""
from __future__ import annotations

import subprocess
import sys

__all__ = ["run_streamlit"]


def run_streamlit(host: str = "0.0.0.0", port: int = 8501) -> str:
    """
    Запускает Streamlit дашборд в фоновом процессе.

    Returns:
        Строка с результатом: успех или ошибка установки.
    """
    try:
        import streamlit  # type: ignore[import]  # noqa: F401
    except ImportError:
        return (
            "❌ Streamlit не установлен.\n"
            "  Установи: pip install streamlit\n"
            "  Затем повтори команду."
        )

    cmd = [
        sys.executable, "-m", "streamlit", "run",
        "src/interface/streamlit_app.py",
        "--server.address", host,
        "--server.port", str(port),
        "--server.headless", "true",
    ]

    proc = subprocess.Popen(cmd)
    return f"🌐 Streamlit дашборд запущен (PID {proc.pid}): http://{host}:{port}"
