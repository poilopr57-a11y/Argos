"""src/interface/web_engine.py — Веб-панель ARGOS (FastAPI)"""
from __future__ import annotations
__all__ = ["ArgosWebEngine", "HTML_TEMPLATE"]

HTML_TEMPLATE = """<!DOCTYPE html>
<html lang="ru">
<head><meta charset="UTF-8"><title>ARGOS v1.33 MASTER</title></head>
<body style="background:#000;color:#00FF41;font-family:monospace">
<h1>ARGOS v1.33 ONLINE</h1>
<p>NODE_ID: Master_7F2A | STATUS: ONLINE</p>
<div id="nodes">
  <div class="node">DESKTOP MASTER</div>
  <div class="node">PHONE NODE</div>
  <div class="node">WEARABLE</div>
  <div class="node">WEB PORTAL</div>
</div>
<div id="metrics">SWARM METRICS</div>
<button onclick="alert('TAP TO SYNC')">TAP TO SYNC</button>
<p class="status">STABLE</p>
<button id="c2">C2 OVERRIDE</button>
</body>
</html>"""


class ArgosWebEngine:
    """FastAPI веб-движок ARGOS."""

    def __init__(self, core=None, port: int = 8080) -> None:
        self._core = core
        self._port = port

    def run(self) -> None:
        try:
            import uvicorn
            from fastapi import FastAPI
            app = FastAPI(title="ARGOS Dashboard")

            @app.get("/")
            def index():
                from fastapi.responses import HTMLResponse
                return HTMLResponse(HTML_TEMPLATE)

            @app.get("/health")
            def health():
                return {"status": "ok", "version": "2.2.0", "uptime": 0}

            uvicorn.run(app, host="0.0.0.0", port=self._port, log_level="warning")
        except Exception as e:
            print(f"[WebEngine] {e}")

    def start(self) -> str:
        import threading
        t = threading.Thread(target=self.run, daemon=True)
        t.start()
        return f"🌐 Веб-панель запущена: http://localhost:{self._port}"
