"""src/interface/kivy_ma.py — Kivy MA интерфейс ARGOS"""
from __future__ import annotations
__all__ = ["SovereignNode", "SovereignNodeMA"]


class SovereignNode:
    """Автономный Kivy-узел ARGOS."""
    def __init__(self, core=None) -> None:
        self._core = core

    def process_all(self, cmd: str) -> str:
        return f"Exec: {cmd}"


# Backward-compat alias
SovereignNodeMA = SovereignNode
