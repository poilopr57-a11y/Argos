"""src/knowledge/grist_git_sync.py — Grist ↔ Git синхронизация"""
from __future__ import annotations
import csv, io, os, subprocess
from pathlib import Path
from typing import Optional

try:
    import requests as _req
except ImportError:
    _req = None  # type: ignore

__all__ = ["GristGitSync"]


class GristGitSync:
    def __init__(self, api_key: str, doc_id: str, git_repo_path: str = ".") -> None:
        self._key  = api_key
        self._doc  = doc_id
        self._repo = Path(git_repo_path).resolve()
        self._server = os.environ.get("GRIST_SERVER_URL", "https://docs.getgrist.com")
        self.last_commit_hash: str = ""

    def _headers(self) -> dict:
        return {"Authorization": f"Bearer {self._key}"}

    def export_table_csv(self, table_name: str) -> str:
        if _req is None:
            raise RuntimeError("requests not installed")
        url = f"{self._server}/api/docs/{self._doc}/tables/{table_name}/records"
        resp = _req.get(url, headers=self._headers(), timeout=15)
        resp.raise_for_status()
        records = resp.json().get("records", [])
        if not records:
            return ""
        fields = sorted(records[0]["fields"].keys())
        buf = io.StringIO()
        writer = csv.writer(buf)
        writer.writerow(fields)
        for r in records:
            writer.writerow([r["fields"].get(f, "") for f in fields])
        return buf.getvalue()

    def commit_csvs(self, tables: dict[str, str], message: str = "grist snapshot") -> str:
        for name, csv_text in tables.items():
            safe = name.replace("/", "_").replace("\\", "_")
            path = self._repo / f"{safe}.csv"
            path.write_text(csv_text, encoding="utf-8")
        self._git("add", "-A")
        self._git("commit", "-m", message)
        self.last_commit_hash = self._git_output("rev-parse", "HEAD").strip()
        return f"Committed: {self.last_commit_hash[:8]}"

    def load_csv_from_git(self, table_name: str, commit: str = "HEAD") -> str:
        safe = table_name.replace("/", "_")
        return self._git_output("show", f"{commit}:{safe}.csv")

    def get_changed_tables(self, from_commit: str, to_commit: str) -> list[str]:
        out = self._git_output("diff", "--name-only", from_commit, to_commit)
        tables = []
        for line in out.splitlines():
            if line.endswith(".csv"):
                tables.append(line[:-4])
        return tables

    def _git(self, *args: str) -> None:
        subprocess.run(["git"] + list(args), cwd=self._repo, check=True, capture_output=True, text=True)

    def _git_output(self, *args: str) -> str:
        r = subprocess.run(["git"] + list(args), cwd=self._repo, check=True, capture_output=True, text=True)
        return r.stdout
