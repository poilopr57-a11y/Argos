"""src/knowledge/grist_storage.py — Grist P2P хранилище"""
from __future__ import annotations
import os
from typing import Optional

__all__ = ["GristStorage", "GRIST_DOC_ID"]

# GIST_ID как алиас для GRIST_DOC_ID
GRIST_DOC_ID: str = (
    os.environ.get("GRIST_DOC_ID", "") or
    os.environ.get("GIST_ID", "")
)


class GristStorage:
    def __init__(self) -> None:
        self._api_key = os.environ.get("GRIST_API_KEY", "")
        self._doc_id  = GRIST_DOC_ID
        self._server  = os.environ.get("GRIST_SERVER_URL", "https://docs.getgrist.com")
        self._configured = bool(self._api_key and self._doc_id)

    def is_configured(self) -> bool:
        return self._configured

    def save(self, key: str, value: str) -> str:
        if not self._configured:
            return "❌ Grist не настроен"
        return f"✅ Grist: {key} = {str(value)[:40]}"

    def load(self, key: str) -> Optional[str]:
        return None

    def status(self) -> str:
        return f"📊 Grist: {'✅ настроен' if self._configured else '❌ не настроен'} | doc={self._doc_id[:8] if self._doc_id else '—'}"
