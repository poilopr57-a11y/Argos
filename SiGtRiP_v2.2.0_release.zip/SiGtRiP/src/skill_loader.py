"""src/skill_loader.py — Загрузчик навыков ARGOS v2"""
from __future__ import annotations
import importlib, importlib.util, os, sys
from pathlib import Path
from typing import Optional

__all__ = ["SkillLoader"]


class SkillLoader:
    """Динамическая загрузка/выгрузка Python-навыков."""

    def __init__(self, skills_dir: str = "src/skills") -> None:
        self._dir     = Path(skills_dir)
        self._loaded: dict[str, object] = {}

    def load(self, name: str) -> Optional[str]:
        skill_path = self._dir / name / "skill.py"
        if not skill_path.exists():
            skill_path = self._dir / f"{name}.py"
        if not skill_path.exists():
            return f"❌ Навык {name!r} не найден"
        try:
            spec = importlib.util.spec_from_file_location(f"skill_{name}", skill_path)
            mod  = importlib.util.module_from_spec(spec)  # type: ignore[arg-type]
            spec.loader.exec_module(mod)  # type: ignore[union-attr]
            self._loaded[name] = mod
            entry = getattr(mod, "on_load", None)
            if callable(entry):
                return entry()
            return f"✅ Навык {name!r} загружен"
        except Exception as e:
            return f"❌ Ошибка загрузки {name!r}: {e}"

    def unload(self, name: str) -> str:
        mod = self._loaded.pop(name, None)
        if not mod:
            return f"⚠️ Навык {name!r} не загружен"
        fn = getattr(mod, "on_unload", None)
        if callable(fn):
            fn()
        return f"✅ Навык {name!r} выгружен"

    def handle(self, text: str) -> Optional[str]:
        """Пробует обработать текст через все загруженные навыки."""
        for name, mod in self._loaded.items():
            fn = getattr(mod, "handle", None)
            if callable(fn):
                try:
                    result = fn(text)
                    if result is not None:
                        return result
                except Exception:
                    pass
        return None

    def list_skills(self) -> str:
        if not self._loaded:
            return "📭 Нет загруженных навыков"
        lines = [f"📋 Навыки ({len(self._loaded)}):"]
        for name, mod in self._loaded.items():
            ver = getattr(mod, "version", getattr(getattr(mod, name.title(), None), "version", "?"))
            lines.append(f"  ✅ {name} v{ver}")
        return "\n".join(lines)

    def available(self) -> list[str]:
        """Список доступных навыков в директории."""
        result = []
        if not self._dir.exists():
            return result
        for item in self._dir.iterdir():
            if item.is_dir() and (item / "skill.py").exists():
                result.append(item.name)
            elif item.suffix == ".py" and item.stem != "__init__":
                result.append(item.stem)
        return sorted(result)
