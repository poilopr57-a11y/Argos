"""src/admin.py — Файловый менеджер ARGOS"""
from __future__ import annotations
import os, shutil
from pathlib import Path
from typing import Optional

__all__ = ["ArgosAdmin"]


class ArgosAdmin:
    """Файловые операции: create, read, edit, append, rename, copy, delete, list."""

    def create_file(self, path: str, content: str = "") -> str:
        try:
            p = Path(path)
            p.parent.mkdir(parents=True, exist_ok=True)
            p.write_text(content, encoding="utf-8")
            return f"✅ Файл создан: {path}"
        except Exception as e:
            return f"Ошибка: {e}"

    def read_file(self, path: str, max_chars: int = 2000) -> str:
        try:
            p = Path(path)
            if not p.exists(): return f"Ошибка: файл не найден"
            size = p.stat().st_size
            try:
                text = p.read_text(encoding="utf-8")
            except UnicodeDecodeError:
                return f"📄 {path} ({size} байт) — двоичный файл"
            shown = text[:max_chars]
            note = f"\n[показано {max_chars} из {size}]" if len(text) > max_chars else ""
            return f"📄 {path} ({size} байт):\n{shown}{note}"
        except Exception as e:
            return f"Ошибка: {e}"

    def edit_file(self, path: str, old_text: str, new_text: str) -> str:
        try:
            p = Path(path)
            if not p.exists(): return f"Ошибка: файл не найден"
            content = p.read_text(encoding="utf-8")
            if old_text not in content:
                return f"❌ Текст не найден в файле: {old_text[:40]}"
            updated = content.replace(old_text, new_text, 1)
            p.write_text(updated, encoding="utf-8")
            return f"✅ Заменено в {path}"
        except Exception as e:
            return f"Ошибка: {e}"

    def append_file(self, path: str, content: str) -> str:
        try:
            p = Path(path)
            p.parent.mkdir(parents=True, exist_ok=True)
            with open(p, "a", encoding="utf-8") as f:
                f.write(content)
            return f"✅ Добавлено в {path}"
        except Exception as e:
            return f"Ошибка: {e}"

    def rename_file(self, src: str, dst: str) -> str:
        try:
            s = Path(src)
            if not s.exists(): return f"❌ Не найден: {src}"
            s.rename(dst)
            return f"✅ Переименован: {src} → {dst}"
        except Exception as e:
            return f"Ошибка: {e}"

    def copy_file(self, src: str, dst: str) -> str:
        try:
            s = Path(src)
            if not s.exists(): return f"❌ Не найден: {src}"
            if s.is_dir():
                shutil.copytree(src, dst)
            else:
                shutil.copy2(src, dst)
            return f"✅ Скопирован: {src} → {dst}"
        except Exception as e:
            return f"Ошибка: {e}"

    def delete_item(self, path: str) -> str:
        try:
            p = Path(path)
            if not p.exists(): return f"Объект не найден: {path}"
            if p.is_dir():
                shutil.rmtree(p)
            else:
                p.unlink()
            return f"🗑️ Удалён: {path}"
        except Exception as e:
            return f"Ошибка: {e}"

    def list_dir(self, path: str = ".") -> str:
        try:
            p = Path(path)
            if not p.exists(): return f"Ошибка: директория не найдена"
            items = sorted(p.iterdir(), key=lambda x: (x.is_file(), x.name))
            lines = [f"📂 {path}:"]
            for item in items[:50]:
                icon = "📄" if item.is_file() else "📁"
                lines.append(f"  {icon} {item.name}")
            return "\n".join(lines)
        except Exception as e:
            return f"Ошибка: {e}"

    def get_stats(self) -> str:
        return "📊 ArgosAdmin: файловый менеджер готов"
