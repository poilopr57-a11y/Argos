# 📱 ARGOS на Android через Termux — Полное руководство

## Предварительные требования

1. **Termux** — скачать с [F-Droid](https://f-droid.org/packages/com.termux/) (НЕ с Google Play — там старая версия)
2. **Android 7+**
3. Интернет-соединение (~500 МБ для полной установки с ML-пакетами)

---

## ⚡ Быстрая установка (одна команда)

Открой Termux и выполни:

```bash
curl -fsSL https://raw.githubusercontent.com/sigtrip/v1-3/main/install_termux.sh | bash
```

Или скачай и запусти вручную:

```bash
curl -fsSL https://raw.githubusercontent.com/sigtrip/v1-3/main/install_termux.sh -o install.sh
bash install.sh
```

---

## 🔧 Пошаговая ручная установка

### Шаг 1 — Обновление Termux

```bash
pkg update && pkg upgrade -y
```

### Шаг 2 — Доступ к хранилищу (один раз)

```bash
termux-setup-storage
```
→ Разреши доступ в диалоге Android.

### Шаг 3 — Базовые пакеты

```bash
pkg install -y python git curl wget openssl clang make
```

### Шаг 4 — Клонирование ARGOS

```bash
git clone --depth=1 https://github.com/sigtrip/v1-3.git ~/argos
cd ~/argos
```

### Шаг 5 — Python-зависимости

```bash
# Ядро
pip install requests python-dotenv psutil cryptography packaging

# AI-провайдеры
pip install google-genai google-generativeai openai ollama

# Telegram
pip install aiogram python-telegram-bot

# ML (может занять 5-10 минут)
pip install scikit-learn numpy beautifulsoup4

# Web
pip install fastapi uvicorn aiosqlite

# IoT
pip install paho-mqtt pyserial
```

### Шаг 6 — Настройка конфигурации

```bash
cp .env.example .env
nano .env
```

Минимально заполни:
```env
# Бесплатный Gemini: https://aistudio.google.com/app/apikey
GEMINI_API_KEY=твой_ключ

# Telegram (опционально)
TELEGRAM_BOT_TOKEN=токен_от_BotFather
USER_ID=твой_telegram_id
```

### Шаг 7 — Первичная инициализация

```bash
python genesis.py
```

### Шаг 8 — Запуск

```bash
python main.py --no-gui
```

---

## 🤖 Ollama (локальный LLM на Android)

Ollama позволяет запускать AI прямо на телефоне без интернета.

### Установка

```bash
# Метод 1: через pkg (если доступно)
pkg install ollama

# Метод 2: скачать бинарник arm64
curl -L https://github.com/ollama/ollama/releases/latest/download/ollama-linux-arm64 \
     -o $PREFIX/bin/ollama
chmod +x $PREFIX/bin/ollama
```

### Запуск и загрузка модели

```bash
# В отдельной сессии Termux
ollama serve &

# Загрузить лёгкую модель (1.1 ГБ)
ollama pull phi3:mini

# Или более мощную (4.7 ГБ, нужно 6+ ГБ RAM)
ollama pull llama3.2:3b
```

### Добавить в .env

```env
OLLAMA_HOST=http://localhost:11434
OLLAMA_MODEL=phi3:mini
```

---

## 📋 Команды после установки

| Команда | Описание |
|---------|----------|
| `argos` | Запуск ARGOS |
| `argos --no-gui` | Headless (только Telegram + P2P) |
| `argos-server` | Сервер-режим |
| `argos-update` | Обновление из GitHub |
| `argos-health` | Диагностика системы |

---

## 🔒 Фоновая работа через Termux:Boot

Чтобы ARGOS запускался при перезагрузке телефона:

```bash
# 1. Установи Termux:Boot из F-Droid
# 2. Создай скрипт автозапуска
mkdir -p ~/.termux/boot
cat > ~/.termux/boot/argos.sh << 'EOF'
#!/data/data/com.termux/files/usr/bin/bash
# Ждём загрузки системы
sleep 10
# Запускаем Ollama если нужно
ollama serve &>/dev/null &
sleep 5
# Запускаем ARGOS в headless режиме
cd ~/argos && python main.py --no-gui >> ~/argos/logs/boot.log 2>&1 &
EOF
chmod +x ~/.termux/boot/argos.sh
```

---

## 🔔 Уведомления через Termux:API

```bash
# Установи Termux:API из F-Droid
pkg install termux-api

# Тест
termux-notification --title "ARGOS" --content "Система запущена"
```

---

## 🌐 Удалённый доступ через SSH

```bash
# Установи OpenSSH
pkg install openssh

# Запусти SSH-сервер
sshd

# Узнай IP телефона
ifconfig wlan0 | grep 'inet '

# С компьютера подключайся:
# ssh -p 8022 user@192.168.x.x
```

---

## ⚠️ Решение частых проблем

### "CERTIFICATE_VERIFY_FAILED"
```bash
pip install certifi
export SSL_CERT_FILE=$(python -c "import certifi; print(certifi.where())")
```

### "numpy / scikit-learn не устанавливается"
```bash
pkg install python-numpy python-scikit-learn
```

### "Нет места на устройстве"
```bash
# Очистить кэш pip
pip cache purge
# Удалить ненужные файлы
rm -rf ~/.cache
```

### "ModuleNotFoundError"
```bash
cd ~/argos
pip install -r requirements.txt
```

### Медленная установка
```bash
# Используй зеркало PyPI
pip install -i https://pypi.tuna.tsinghua.edu.cn/simple <package>
```

---

## 📊 Минимальные требования

| Компонент | Минимум | Рекомендуется |
|-----------|---------|---------------|
| Android | 7.0 | 10+ |
| RAM | 2 ГБ | 4+ ГБ |
| Хранилище | 1 ГБ | 5+ ГБ (с Ollama) |
| Процессор | ARM64 | Snapdragon/Dimensity |

---

## 🙏 Поддержка

- GitHub Issues: https://github.com/sigtrip/v1-3/issues
- Telegram: настрой бота и пиши `помощь`

*"Аргос не спит. Аргос видит. Аргос помнит."*
