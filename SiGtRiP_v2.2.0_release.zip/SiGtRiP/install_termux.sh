#!/data/data/com.termux/files/usr/bin/bash
# ============================================================
#  ARGOS Universal OS v2.2.0 — Установщик для Termux
#  Архив: files (18).zip
#  Использование: bash install_termux.sh
# ============================================================

set -e

GREEN='\033[0;32m'; CYAN='\033[0;36m'
YELLOW='\033[1;33m'; RED='\033[0;31m'
BOLD='\033[1m'; NC='\033[0m'

ok()   { echo -e "${GREEN}✅ $1${NC}"; }
info() { echo -e "${CYAN}ℹ️  $1${NC}"; }
warn() { echo -e "${YELLOW}⚠️  $1${NC}"; }
err()  { echo -e "${RED}❌ $1${NC}"; exit 1; }
step() { echo -e "\n${BOLD}${CYAN}═══ $1 ═══${NC}"; }

ARCHIVE_NAME="files (18).zip"
INSTALL_DIR="$HOME/SiGtRiP"

echo -e "${BOLD}${CYAN}"
cat << 'LOGO'
  ██████╗ ██████╗  ██████╗  ██████╗ ███████╗
  ██╔══██╗██╔══██╗██╔════╝ ██╔═══██╗██╔════╝
  ███████║██████╔╝██║  ███╗██║   ██║███████╗
  ██╔══██║██╔══██╗██║   ██║██║   ██║╚════██║
  ██║  ██║██║  ██║╚██████╔╝╚██████╔╝███████║
  ╚═╝  ╚═╝╚═╝  ╚═╝ ╚═════╝  ╚═════╝ ╚══════╝
LOGO
echo -e "  Universal OS v2.2.0 — Termux Installer${NC}\n"

# ══════════════════════════════════════════════════════════════
step "1/7 Поиск архива '${ARCHIVE_NAME}'"
# ══════════════════════════════════════════════════════════════

ARCHIVE_PATH=""
SEARCH_PATHS=(
    "$HOME/storage/downloads/${ARCHIVE_NAME}"
    "$HOME/storage/shared/Download/${ARCHIVE_NAME}"
    "/sdcard/Download/${ARCHIVE_NAME}"
    "/sdcard/${ARCHIVE_NAME}"
    "$HOME/${ARCHIVE_NAME}"
    "$(pwd)/${ARCHIVE_NAME}"
)

for path in "${SEARCH_PATHS[@]}"; do
    if [ -f "$path" ]; then
        ARCHIVE_PATH="$path"
        ok "Архив найден: $path"
        break
    fi
done

if [ -z "$ARCHIVE_PATH" ]; then
    warn "Архив не найден автоматически. Ищу в:"
    for path in "${SEARCH_PATHS[@]}"; do echo "    $path"; done
    echo ""
    echo -n "  Введи полный путь к архиву: "
    read -r USER_PATH
    [ -f "$USER_PATH" ] && ARCHIVE_PATH="$USER_PATH" && ok "Найден: $USER_PATH" || \
        err "Архив не найден. Скопируй его в Загрузки и повтори."
fi

# ══════════════════════════════════════════════════════════════
step "2/7 Обновление Termux и базовые пакеты"
# ══════════════════════════════════════════════════════════════

info "Обновляю пакеты..."
pkg update -y 2>/dev/null || true
pkg install -y unzip python git curl 2>/dev/null || \
    apt-get install -y unzip python git curl 2>/dev/null || \
    warn "Некоторые пакеты не установились"
ok "Базовые пакеты готовы"

# ══════════════════════════════════════════════════════════════
step "3/7 Проверка Python"
# ══════════════════════════════════════════════════════════════

PYTHON_CMD=""
for cmd in python3 python python3.11 python3.10; do
    if command -v "$cmd" &>/dev/null; then
        VER=$("$cmd" -c "import sys; print(f'{sys.version_info.major}.{sys.version_info.minor}')" 2>/dev/null || echo "0.0")
        MAJOR=$(echo "$VER" | cut -d. -f1)
        MINOR=$(echo "$VER" | cut -d. -f2)
        if [ "$MAJOR" -ge 3 ] && [ "$MINOR" -ge 10 ]; then
            PYTHON_CMD="$cmd"
            ok "Python $VER ($cmd)"
            break
        fi
    fi
done

if [ -z "$PYTHON_CMD" ]; then
    info "Устанавливаю Python..."
    pkg install -y python 2>/dev/null || err "Не удалось установить Python"
    PYTHON_CMD="python3"
    ok "Python установлен: $($PYTHON_CMD --version 2>&1)"
fi

# ══════════════════════════════════════════════════════════════
step "4/7 Распаковка архива"
# ══════════════════════════════════════════════════════════════

if [ -d "$INSTALL_DIR" ]; then
    warn "Папка $INSTALL_DIR уже существует."
    echo -n "  Перезаписать? (y/n): "
    read -r OVR
    [ "$OVR" = "y" ] || [ "$OVR" = "Y" ] && rm -rf "$INSTALL_DIR" && info "Удалено" || \
        err "Установка отменена. Удали $INSTALL_DIR вручную и повтори."
fi

mkdir -p "$INSTALL_DIR"
info "Распаковываю архив..."
unzip -q "$ARCHIVE_PATH" -d "$INSTALL_DIR" 2>/dev/null || \
    err "Не удалось распаковать. Проверь целостность файла."
ok "Архив распакован"

# Если архив содержит одну вложенную папку — поднимаем содержимое
SUBDIRS=$(find "$INSTALL_DIR" -mindepth 1 -maxdepth 1 -type d 2>/dev/null | wc -l)
FILES=$(find "$INSTALL_DIR" -mindepth 1 -maxdepth 1 -type f 2>/dev/null | wc -l)
if [ "$SUBDIRS" -eq 1 ] && [ "$FILES" -eq 0 ]; then
    SUBDIR=$(find "$INSTALL_DIR" -mindepth 1 -maxdepth 1 -type d | head -1)
    if [ -f "${SUBDIR}/main.py" ] || [ -d "${SUBDIR}/src" ]; then
        info "Перемещаю содержимое из вложенной папки: $(basename $SUBDIR)..."
        mv "$SUBDIR"/* "$INSTALL_DIR/" 2>/dev/null || true
        mv "$SUBDIR"/.[!.]* "$INSTALL_DIR/" 2>/dev/null || true
        rmdir "$SUBDIR" 2>/dev/null || true
        ok "Структура скорректирована"
    fi
fi

# Проверяем структуру
[ -f "$INSTALL_DIR/main.py" ] && ok "main.py найден" || warn "main.py не найден — возможно нестандартная структура"
[ -d "$INSTALL_DIR/src" ]    && ok "src/ найден"   || warn "src/ не найден"

info "Файлов в архиве: $(ls $INSTALL_DIR | wc -l)"

# ══════════════════════════════════════════════════════════════
step "5/7 Установка Python-зависимостей"
# ══════════════════════════════════════════════════════════════

cd "$INSTALL_DIR"
"$PYTHON_CMD" -m pip install --upgrade pip --quiet 2>/dev/null || true

install_pkg() {
    local label="$1"; shift
    if "$PYTHON_CMD" -m pip install --quiet "$@" 2>/dev/null; then
        ok "$label"
    else
        warn "$label — не установился (не критично)"
    fi
}

install_pkg "Базовые"   requests python-dotenv psutil beautifulsoup4 packaging
install_pkg "AI"        google-genai ollama
install_pkg "Telegram"  python-telegram-bot aiogram
install_pkg "Web"       fastapi uvicorn
install_pkg "ML"        scikit-learn numpy
install_pkg "Безопасность" cryptography

# ══════════════════════════════════════════════════════════════
step "6/7 Инициализация"
# ══════════════════════════════════════════════════════════════

cd "$INSTALL_DIR"
mkdir -p data logs src/skills config modules tests/generated assets

# Genesis
if [ -f "genesis.py" ]; then
    "$PYTHON_CMD" genesis.py 2>/dev/null && ok "genesis.py выполнен" || warn "genesis.py: ошибка (не критично)"
fi

# .env
if [ ! -f ".env" ]; then
    if [ -f ".env.example" ]; then
        cp .env.example .env && ok ".env создан из .env.example"
    else
cat > .env << 'ENVEOF'
# ARGOS .env — заполни свои ключи
# Получи Gemini ключ бесплатно: https://aistudio.google.com/app/apikey
GEMINI_API_KEY=

# Telegram бот (@BotFather) и твой ID (@userinfobot)
TELEGRAM_BOT_TOKEN=
USER_ID=

ARGOS_NETWORK_SECRET=argos_secret_2026
ARGOS_HOMEOSTASIS=on
ARGOS_CURIOSITY=on
ARGOS_VOICE_DEFAULT=off
ARGOS_TASK_WORKERS=1
OLLAMA_HOST=http://localhost:11434
ENVEOF
        ok ".env создан (заполни GEMINI_API_KEY и TELEGRAM_BOT_TOKEN)"
    fi
else
    ok ".env уже существует"
fi

# Права
chmod +x "$INSTALL_DIR"/*.sh 2>/dev/null || true

# ══════════════════════════════════════════════════════════════
step "7/7 Команды запуска"
# ══════════════════════════════════════════════════════════════

TERMUX_BIN="$PREFIX/bin"

# argos — основная команда
cat > "$TERMUX_BIN/argos" << SEOF
#!/data/data/com.termux/files/usr/bin/bash
cd "$HOME/SiGtRiP" && exec $PYTHON_CMD main.py "\$@"
SEOF
chmod +x "$TERMUX_BIN/argos"
ok "Команда 'argos' (GUI режим)"

# argos-bot — headless
cat > "$TERMUX_BIN/argos-bot" << SEOF
#!/data/data/com.termux/files/usr/bin/bash
cd "$HOME/SiGtRiP" && exec $PYTHON_CMD main.py --no-gui "\$@"
SEOF
chmod +x "$TERMUX_BIN/argos-bot"
ok "Команда 'argos-bot' (headless)"

# argos-health
cat > "$TERMUX_BIN/argos-health" << SEOF
#!/data/data/com.termux/files/usr/bin/bash
cd "$INSTALL_DIR" && exec $PYTHON_CMD health_check.py "\$@"
SEOF
chmod +x "$TERMUX_BIN/argos-health"
ok "Команда 'argos-health'"

# ~/.bashrc алиасы
BASHRC="$HOME/.bashrc"
if ! grep -q "# ARGOS aliases" "$BASHRC" 2>/dev/null; then
cat >> "$BASHRC" << 'ALIASEOF'

# ARGOS aliases
alias argos='cd ~/SiGtRiP && python3 main.py --no-gui'
alias argos-health='cd ~/SiGtRiP && python3 health_check.py'
alias argos-dir='cd ~/SiGtRiP'
alias argos-env='nano ~/SiGtRiP/.env'
ALIASEOF
    ok "Алиасы добавлены в ~/.bashrc"
fi

# ══════════════════════════════════════════════════════════════
# ИТОГ
# ══════════════════════════════════════════════════════════════
echo ""
echo -e "${BOLD}${GREEN}════════════════════════════════════════${NC}"
echo -e "${BOLD}${GREEN}  🔱 ARGOS УСТАНОВЛЕН В ~/SiGtRiP${NC}"
echo -e "${BOLD}${GREEN}════════════════════════════════════════${NC}"
echo ""
echo -e "  📁 Путь    : ${CYAN}$INSTALL_DIR${NC}"
echo -e "  🐍 Python  : ${CYAN}$($PYTHON_CMD --version 2>&1)${NC}"
echo -e "  📦 .py     : ${CYAN}$(find $INSTALL_DIR -name '*.py' 2>/dev/null | wc -l) файлов${NC}"
echo ""
echo -e "${BOLD}  🚀 Как запустить:${NC}"
echo ""
echo -e "  ${YELLOW}1. Активируй алиасы:${NC}"
echo -e "     ${CYAN}source ~/.bashrc${NC}"
echo ""
echo -e "  ${YELLOW}2. Впиши ключи (необязательно для старта):${NC}"
echo -e "     ${CYAN}nano ~/SiGtRiP/.env${NC}"
echo ""
echo -e "  ${YELLOW}3. Запусти ARGOS:${NC}"
echo -e "     ${CYAN}argos-bot${NC}          # headless (Telegram + P2P)"
echo -e "     ${CYAN}argos-health${NC}       # проверка системы"
echo ""
echo -e "  ${YELLOW}Или напрямую:${NC}"
echo -e "     ${CYAN}cd ~/SiGtRiP && python3 main.py --no-gui${NC}"
echo ""
echo -e "${BOLD}${GREEN}════════════════════════════════════════${NC}"
